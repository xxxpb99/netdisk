#include "mytcpserver.h"
#include <QtDebug>
MyTcpServer::MyTcpServer()
{
    //单例模式
}

MyTcpServer &MyTcpServer::getInstance()
{
    //到后面凡是需要用到MyTcpServer的时候，直接通过类名getInstance获得静态的局部对象来进行操作，无论调用多少次，有且仅有一个对象
    static MyTcpServer instance;
    return instance;
}

//Tcpserver监听之后，一旦有客户端过来，他就会自动去调用incomingConnection
void MyTcpServer::incomingConnection(qintptr socketDescriptor)
{
    //只要有客户端连接过来了就打印一下
    qDebug()<<"new client connected";
    //产生一个socket，然后把socketDescriptor描述符放在socket里面，就可以进行收发数据
    MyTcpSocket *pTcpSocket = new MyTcpSocket;
    pTcpSocket->setSocketDescriptor(socketDescriptor);
    //再放到链表里面取
    m_tcpSocketList.append(pTcpSocket);

    connect(pTcpSocket, SIGNAL(offline(MyTcpSocket*)), this, SLOT(deleteSocket(MyTcpSocket*)));


}

void MyTcpServer::reSend(const char *pername, PDU *pdu)
{
    if(NULL==pername||NULL==pdu){
        return;
    }
    QString strName = pername;
    //遍历链表
    for(int i=0; i<m_tcpSocketList.size();i++)
    {
        //qDebug()<<m_tcpSocketList.at(i)->getName();
        if(strName==m_tcpSocketList.at(i)->getName())
        {
            m_tcpSocketList.at(i)->write((char*)pdu,pdu->uiPDULen);
            break;
        }
    }
}

void MyTcpServer::deleteSocket(MyTcpSocket *mysocket)
{
    QList<MyTcpSocket*>::iterator iter = m_tcpSocketList.begin();
    for(;iter!=m_tcpSocketList.end(); iter++)
    {
        if(mysocket==*iter){
            delete  *iter;
            *iter = NULL;
            m_tcpSocketList.erase(iter);
            break;
        }
    }
    for(int i=0; i<m_tcpSocketList.size();i++)
    {
        qDebug()<<m_tcpSocketList.at(i)->getName();
    }
}

