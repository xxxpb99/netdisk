#include "operatedb.h"
#include <QDebug>
#include <QMessageBox>
OperateDB::OperateDB(QObject *parent) : QObject(parent)
{
    //在构造函数里面告诉QsqlDatabase我们要操作的数据库是一个什么数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE");
}

//当我们通过类名调用getInstance的时候，都会返回静态对象的引用，因为他是静态的，所以每次调用都是用一个对象
OperateDB &OperateDB::getInstance()
{
    //在静态的成员函数里面，再定义一个静态的对象
    static OperateDB instance;
    //返回静态对象的引用
    return instance;
}

void OperateDB::init()
{
    //连接数据库
    //localhost本地，远程就写远程的ip
    m_db.setHostName("localhost");
    //需要操作的数据库的名字
    m_db.setDatabaseName("F:/Documents/Desktop/wangpan/TcpServer/cloud.db");
    //打开数据库
    if(m_db.open()){
        //成功——查询数据
        QSqlQuery query;
        query.exec("select * from usrInfo");
        while (query.next()) {
            QString data = QString("%1,%2,%3").arg(query.value(0).toString()).arg(query.value(1).toString()).arg(query.value(2).toString());
            qDebug()<<data;
        }

    }else {
        QMessageBox::critical(NULL,"打开数据库","打开数据库失败");
    }

}

OperateDB::~OperateDB()
{
    //关掉数据库
    m_db.close();
}

bool OperateDB::handleRegist(const char *name, const char *Pwd)
{
    //将要执行的语句放在caQuery里面
    //    char caQuery[128] = {'\0'};
    //    sprintf(caQuery, "");

    if(NULL==name || NULL== Pwd){
        //考虑形参的有效性
        qDebug()<<"name |pwd is NUll";
        return  false;
    }
    //拼接
    QString data = QString("insert into usrInfo (name,pwd) values(\'%1\',\'%2\')").arg(name).arg(Pwd);
    qDebug()<<data;
    QSqlQuery query;
    return query.exec(data);
}

bool OperateDB::handleLogin(const char *name, const char *Pwd)
{
    //将要执行的语句放在caQuery里面
    //    char caQuery[128] = {'\0'};
    //    sprintf(caQuery, "");

    if(NULL==name || NULL== Pwd){
        //考虑形参的有效性
        qDebug()<<"name |pwd is NUll";
        return  false;
    }

    //拼接一个查询语句
    //必须三个条件都满足
    QString data = QString("select * from usrInfo where name=\'%1\' and pwd=\'%2\' and online =0").arg(name).arg(Pwd);
    qDebug()<<data;
    QSqlQuery query;
    //select * 返回的是一个结果集
    query.exec(data);
    //获得每一个结果集
    //调用nect的时候会调用它的第一条数据,以此类推。直到没有数据，返回的是一个false
    //条件不匹配那就是没有数据，直接false，退出函数
    if(query.next()){
        //更新online
        data = QString("update usrInfo set online=1 where name=\'%1\' and pwd=\'%2\'").arg(name).arg(Pwd);
        qDebug()<<data;
        QSqlQuery query;
        query.exec(data);
        return  true;
    }else {
        return  false;
    }
}

void OperateDB::handleOffline(const char *name)
{

    if(NULL==name){
        //考虑形参的有效性
        qDebug()<<"name is NUll";
        return;
    }
    QString data = QString("update usrInfo set online=0 where name=\'%1\'").arg(name);
    qDebug()<<data;
    QSqlQuery query;
    query.exec(data);
}

QStringList OperateDB::handleAllOnline()
{
    QString data = QString("select name from usrInfo where online =1");
    QSqlQuery query;
    query.exec(data);

    QStringList result;
    result.clear();

    //循环的调用next函数,来获得每一条结果集
    while (query.next()) {
        result.append(query.value(0).toString());
    }
    //qDebug()<<result;
    return  result;
}

int OperateDB::handleSearchUser(const char *name)
{
    if(NULL == name){
        return -1;
    }
    //通过名字去数据库查看对应的记录
    QString data = QString("select online from usrInfo where name = \'%1\'").arg(name);
    QSqlQuery query;
    query.exec(data);
    if(query.next()){
        //查看是否在线
        int ret = query.value(0).toUInt();
        if(1==ret){
            return 1;
        }
        else if(0==ret) {
            return 0;
        }
    }
    else {
        return  -1;
    }
}

int OperateDB::handleAddFriend(const char *pername, const char *name)
{
    //首先对形参的有效性做出判断
    if(NULL==pername||NULL==name)
    {
        return -1;
    }
    //查看是否已经是自己的好友
    //我作为id，我的friendid里面有没有这个名字
    QString data = QString("select * from friend where (id=(select id from usrInfo where name = '\%1\') and friendId= (select id from usrInfo where name = '\%2\'))"
                           "or(id=(select id from usrInfo where name = '\%3\') and friendId=(select id from usrInfo where name = '\%4\'))").arg(pername).arg(name).arg(name).arg(pername);
    qDebug()<<data;
    QSqlQuery query;
    query.exec(data);
    if(query.next()){

        return 0;//双方已经是好友
    }
    else
    {
        data = QString("select online from usrInfo where name = \'%1\'").arg(pername);
        QSqlQuery query;
        query.exec(data);
        if(query.next()){
            //查看是否在线
            int ret = query.value(0).toUInt();
            if(1==ret){
                return 1;//不是好友 在线
            }
            else if(0==ret) {
                return 2;
            }
        }
        else {
            return  3;//对方不存在
        }
    }
}

void OperateDB::handleAgreeAddfriend(const char *pername, const char *name)
{
    //首先对形参的有效性做出判断
    if(NULL==pername||NULL==name)
    {
        return;
    }
    QString data = QString("insert into friend(id,friendId) values((select id from usrInfo where name=\'%1\'),(select id from usrInfo where name=\'%2\'))").arg(pername).arg(name);
    qDebug()<<data;
    QSqlQuery query;
    query.exec(data);
}

QStringList OperateDB::handleFlushFriend(const char *name)
{
    //产生一个list
    QStringList strFriendList;
    strFriendList.clear();
    if(NULL==name)
    {
        return strFriendList;
    }
    //首先找到用户名的id，再通过id到好友表找到好友的id，再根据好友的id到用户表里面找他的名字
    QString data = QString("select name from usrInfo where online=1 and id in (select id from friend where friendId=(select id from usrInfo where name=\'%1\'))").arg(name);
    //qDebug()<<data;
    QSqlQuery query;
    query.exec(data);
    while (query.next()) {
        strFriendList.append( query.value(0).toString());
        qDebug()<<query.value(0).toString();
    }
    //query.clear();

    data = QString("select name from usrInfo where online=1 and id in(select friendId from friend where id=(select id from usrInfo where name=\'%1\'))").arg(name);

    query.exec(data);
    while (query.next()) {
        strFriendList.append( query.value(0).toString());
        qDebug()<<query.value(0).toString();
    }
    return strFriendList;

}

bool OperateDB::handleDeleteFriend(const char *name, const char *friendname)
{
    if(NULL==name||NULL==friendname)
    {
        return false;
    }

    QString data = QString("delete from friend where id=(select id from usrInfo where name=\'%1\') "
                           "and friendId=(select id from usrInfo where name=\'%2\')").arg(name).arg(friendname);
    qDebug()<<data;
    QSqlQuery query;
    query.exec(data);

    data = QString("delete from friend where id=(select id from usrInfo where name=\'%1\') "
                           "and friendId=(select id from usrInfo where name=\'%2\')").arg(friendname).arg(name);
    qDebug()<<data;
    query.exec(data);
    return  true;
}


















