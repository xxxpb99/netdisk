#include "tcpserver.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //关于数据库的测试
    OperateDB::getInstance().init();
    TcpServer w;
    w.show();
    return a.exec();
}
