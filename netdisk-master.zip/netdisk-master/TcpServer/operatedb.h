#ifndef OPERATEDB_H
#define OPERATEDB_H

#include <QObject>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QStringList>
class OperateDB : public QObject
{
    Q_OBJECT
public:
    explicit OperateDB(QObject *parent = nullptr);
    //定义单例，就是把它定义成静态的成员函数，在静态成员函数里面，再定义一个静态的对象，
    //每次通过类名调用静态成员函数的时候，使用静态的局部成员(局部变量)，就可以使用到同一个对象
    static OperateDB& getInstance();
    //将数据库的连接写成一个初始化函数
    void init();
    //产生析构函数
    ~OperateDB();

    //-------------------------注册-----------------------------
    bool handleRegist(const char *name, const char *Pwd);

    //-------------------------登录-----------------------------
    bool handleLogin(const char *name, const char *Pwd);

    //-------------------------注销-----------------------------
    void handleOffline(const char *name);
    //-------------------------处理所有在线用户的函数---------------
    QStringList handleAllOnline();
    //------------------------查找用户------------------------
    int handleSearchUser(const char *name);
    //------------------------加好友--------------------------
    int handleAddFriend(const char *pername, const char *name);
    //同意加好友
    void handleAgreeAddfriend(const char*pername,const char *name);

    //---------------------------刷新好友-------------------------
    QStringList handleFlushFriend(const char *name);
    //--------------------------删除好友-------------------------
    bool handleDeleteFriend(const char *name, const char *friendname);
signals:
public slots:
private:
    QSqlDatabase m_db;//连接数据库

};

#endif // OPERATEDB_H
