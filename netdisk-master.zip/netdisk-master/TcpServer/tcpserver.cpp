#include "tcpserver.h"
#include "ui_tcpserver.h"
#include <QFile>
#include <QMessageBox>
#include <QtDebug>
TcpServer::TcpServer(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TcpServer)
{
    ui->setupUi(this);
    loadConfig();
    MyTcpServer::getInstance().listen(QHostAddress(m_strIP), m_usPort);

}

TcpServer::~TcpServer()
{
    delete ui;
}

void TcpServer::loadConfig()
{
    QFile file(":/server.config");
    if(file.open(QIODevice::ReadOnly)){
        QByteArray baData = file.readAll();
        //将字节转换成字符串
        //c_str()将首地址转换成char*类型的
        QString strData = baData.toStdString().c_str();
        //        qDebug()<<strData;
        file.close();

        //切分字符串
        strData.replace("\r\n", " ");
        //qDebug()<<strData;
        //按照空格进行切分--是一个字符串列表
        QStringList strList =  strData.split(" ");
        //切分完成之后打印一下
        //        for(int i=0; i<strList.size(); i++){
        //            qDebug()<<"------>"<<strList[i];
        //        }

        m_strIP = strList.at(0);
        //端口现在是字符串，现在得转换成无符号的整型
        m_usPort = strList.at(1).toUShort();
        qDebug()<<"ip"<<m_strIP <<"port"<<m_usPort;
    }
    else {
        QMessageBox::critical(this, "open config", "open config failed");
    }
}

