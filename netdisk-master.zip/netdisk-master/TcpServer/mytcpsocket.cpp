#include "mytcpsocket.h"
#include <QtDebug>
#include "mytcpserver.h"
#include <QFileInfoList>
MyTcpSocket::MyTcpSocket()
{
    connect(this, SIGNAL(readyRead()), this, SLOT(recvMsg()));
    connect(this, SIGNAL(disconnected()), this, SLOT(clientOffline()));
    m_bUpload = false;
    m_pTimer = new QTimer;
    connect(m_pTimer, SIGNAL(timeout()), this, SLOT(sendFileToClient()));

}

QString MyTcpSocket::getName()
{
    return  m_strName;
}

void MyTcpSocket::copyDir(QString strSrcDir, QString strDestDir)
{
    //创建目标文件
    QDir dir;
    dir.mkdir(strDestDir);//产生一个目录
    //打开原来要拷贝的目录
    dir.setPath(strSrcDir);
    QFileInfoList fileInfoList =  dir.entryInfoList();
    QString srcTmp;
    QString destTmp;
    //遍历list
    for(int i=0;i<fileInfoList.size();i++)
    {
        if(fileInfoList[i].isFile())
        {//如果是常规文件
            qDebug()<<"filename:"<<fileInfoList[i].fileName();
            srcTmp = strSrcDir + '/' +fileInfoList[i].fileName();
            destTmp = strDestDir + '/' +fileInfoList[i].fileName();
            QFile::copy(srcTmp,destTmp);
        }
        else if (fileInfoList[i].isDir()) {
            if(QString(".") == fileInfoList[i].fileName()||QString("..") == fileInfoList[i].fileName())
            {
                continue;
            }
            srcTmp = strSrcDir + '/' +fileInfoList[i].fileName();
            destTmp = strDestDir + '/' +fileInfoList[i].fileName();
            copyDir(srcTmp,destTmp);//如果是子文件夹，递归进行拷贝
        }
    }
}


void MyTcpSocket::recvMsg()
{
    if(!m_bUpload)
    {
        //打印当前可读的数据大小
        qDebug()<<this->bytesAvailable();
        //收数据
        uint uiPDULen =0;
        //先收4个字节大小的数
        this->read((char*)&uiPDULen, sizeof (uint));
        //根据总的大小，计算实际消息长度
        uint uiMsgLen = uiPDULen-sizeof (PDU);
        //根据实际消息长度，产生一个pdu，接收剩余的数据
        PDU *pdu = mkPDU(uiMsgLen);
        //(char*)pdu +sizeof (uint)从这儿开始放，放uiPDULen-sizeof (uint)些数据
        this->read((char*)pdu +sizeof (uint),uiPDULen-sizeof (uint));
        //qDebug()<<pdu->uiMsgType<<(char*)pdu->caMsg;
        //判断消息类型
        switch (pdu->uiMsgType) {

        //-------------------注册-----------------
        case ENUM_MSG_TYPE_REGIST_REQUEST:
        {
            //打印数据
            char caName[32] = {'\0'};
            char caPwd[32] ={'\0'};
            strncpy(caName, pdu->caData, 32);
            strncpy(caPwd, pdu->caData+32, 32);
            //交给数据库函数去处理
            bool ret = OperateDB::getInstance().handleRegist(caName,caPwd);
            PDU *respdu = mkPDU(0);
            respdu->uiMsgType = ENUM_MSG_TYPE_REGIST_RESPOND;
            if(ret)
            {
                strcpy(respdu->caData, REGIST_OK);
                QDir dir;
                dir.mkdir(QString("./%1").arg(caName));
            }
            else
            {
                strcpy(respdu->caData, REGIST_FAILED);
            }
            //发送
            write((char*)respdu, respdu->uiPDULen);
            //释放空间
            free (respdu);
            respdu =NULL;
            break;
        }
            //------------------登录------------------
        case ENUM_MSG_TYPE_LOGIN_REQUEST:
        {
            //1、查看有没有这个用户，
            //2、再就是查看有没有登陆过
            char caName[32] = {'\0'};
            char caPwd[32] ={'\0'};
            strncpy(caName, pdu->caData, 32);
            strncpy(caPwd, pdu->caData+32, 32);

            bool ret =OperateDB::getInstance().handleLogin(caName,caPwd);
            PDU *respdu = mkPDU(0);
            respdu->uiMsgType = ENUM_MSG_TYPE_LOGIN_RESPOND;
            if(ret)
            {
                strcpy(respdu->caData, LOGIN_OK);
                m_strName = caName;

            }
            else {
                strcpy(respdu->caData, LOGIN_FAILED);
            }
            //发送
            write((char*)respdu, respdu->uiPDULen);
            //释放空间
            free (respdu);
            respdu =NULL;
            break;
        }
            //-------------------------------查看所有用户的请求-----------------
        case ENUM_MSG_TYPE_ALL_ONLINE_REQUEST:
        {
            QStringList ret = OperateDB::getInstance().handleAllOnline();
            //产生多大的pdu,每一个名字占32个字节大小
            uint uiMsglen = ret.size()*32;
            PDU *respdu = mkPDU(uiMsglen);
            respdu->uiMsgType = ENUM_MSG_TYPE_ALL_ONLINE_RESPOND;
            //将用户名循环拷贝到这块空间里面去
            for(int i=0; i<ret.size(); i++){
                memcpy((char*)(respdu->caMsg)+i*32
                       ,ret.at(i).toStdString().c_str()
                       , ret.at(i).size());
            }

            //发送
            write((char*)respdu, respdu->uiPDULen);
            //释放空间
            free (respdu);
            respdu =NULL;
            break;
        }
            //-------------------------------查找用户------------
        case ENUM_MSG_TYPE_SEARCH_USER_REQUEST:
        {
            int ret = OperateDB::getInstance().handleSearchUser(pdu->caData);
            PDU *respdu = mkPDU(0);
            respdu->uiMsgType = ENUM_MSG_TYPE_SEARCH_USER_RESPOND;
            if(-1==ret){
                strcpy(respdu->caData, SEARCH_USER_NO);
            }
            else if (1==ret) {
                strcpy(respdu->caData,SEARCH_USER_ONLINE);
            }
            else if (0==ret) {
                strcpy(respdu->caData, SEARCH_USER_OFFLINE);
            }
            //发送
            write((char*)respdu, respdu->uiPDULen);
            //释放空间
            free (respdu);
            respdu =NULL;
            break;
        }
            //-----------------------------------加好友------------------------------
        case ENUM_MSG_TYPE_ADD_FRIEND_REQUEST:
        {
            char caPerName[32] = {'\0'};
            char caName[32] ={'\0'};
            strncpy(caPerName, pdu->caData, 32);
            strncpy(caName, pdu->caData+32, 32);
            int ret = OperateDB::getInstance().handleAddFriend(caPerName,caName);
            PDU *respdu = NULL;
            if(-1==ret){
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_RESPOND;
                strcpy(respdu->caData, UNKNOW_ERROR);
                //发送
                write((char*)respdu, respdu->uiPDULen);
                //释放空间
                free (respdu);
                respdu =NULL;
            }
            else if(0==ret){
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_RESPOND;
                strcpy(respdu->caData, EXISTED_FRIEND);
                //发送
                write((char*)respdu, respdu->uiPDULen);
                //释放空间
                free (respdu);
                respdu =NULL;
            }
            else if(1==ret){
                //在线
                MyTcpServer::getInstance().reSend(caPerName,pdu);
            }
            else if(2==ret){
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_RESPOND;
                strcpy(respdu->caData, ADD_FRIEND_OFFLINE);
                //发送
                write((char*)respdu, respdu->uiPDULen);
                //释放空间
                free (respdu);
                respdu =NULL;
            }
            else if(3==ret){
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_RESPOND;
                strcpy(respdu->caData, ADD_FRIEND_NO_EXISTED);
                //发送
                write((char*)respdu, respdu->uiPDULen);
                //释放空间
                free (respdu);
                respdu =NULL;
            }
            break;
        }

        case  ENUM_MSG_TYPE_ADD_FRIEND_AGGREE:
        {
            char caPerName[32] = {'\0'};
            char caName[32] ={'\0'};
            strncpy(caPerName, pdu->caData, 32);
            strncpy(caName, pdu->caData+32, 32);
            OperateDB::getInstance().handleAgreeAddfriend(caPerName,caName);
            MyTcpServer::getInstance().reSend(caName,pdu);
            break;
        }

        case  ENUM_MSG_TYPE_ADD_FRIEND_REFUSE:
        {
            char caName[32] ={'\0'};
            strncpy(caName, pdu->caData+32, 32);
            MyTcpServer::getInstance().reSend(caName,pdu);
            break;
        }

            //------------------------------刷新好友---------------------------------
        case ENUM_MSG_TYPE_FLUSH_FRIEND_REQUEST:
        {

            char caName[32] ={'\0'};
            strncpy(caName, pdu->caData, 32);
            QStringList ret = OperateDB::getInstance().handleFlushFriend(caName);

            uint uiMsgLen = ret.size()*32;
            PDU *respdu=mkPDU(uiMsgLen);

            respdu->uiMsgType=ENUM_MSG_TYPE_FLUSH_FRIEND_RESPOND;
            //循环将列表的名字拷贝进去
            for(int i=0;i<ret.size();i++)
            {
                memcpy((char*)(respdu->caMsg)+i*32
                       ,ret.at(i).toStdString().c_str()
                       ,ret.at(i).size());
            }
            //发送
            write((char*)respdu, respdu->uiPDULen);
            //释放空间
            free (respdu);
            respdu =NULL;
            break;
        }

            //------------------------删除好友请求-------------------
        case ENUM_MSG_TYPE_DELETE_FRIEND_REQUEST:
        {
            char caSelfName[32] = {'\0'};
            char caFriendName[32] ={'\0'};
            strncpy(caSelfName, pdu->caData, 32);
            strncpy(caFriendName, pdu->caData+32, 32);
            OperateDB::getInstance().handleDeleteFriend(caSelfName,caFriendName);
            //删除消息提示
            PDU *respdu =mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_DELETE_FRIEND_RESPOND;
            strcpy(respdu->caData,DELETE_FRIEND_OK);
            //发送
            write((char*)respdu, respdu->uiPDULen);
            //释放空间
            free (respdu);
            respdu =NULL;
            //B在线就给提示，否则不给提示
            //在线
            MyTcpServer::getInstance().reSend(caFriendName,pdu);
            break;
        }

            //--------------------------------------私聊请求----------------------
        case ENUM_MSG_TYPE_PRIVATE_CHAT_REQUEST:
        {
            char caPerName[32]={'\0'};
            memcpy(caPerName,pdu->caData+32,32);
            qDebug()<<caPerName;
            MyTcpServer::getInstance().reSend(caPerName,pdu);
            break;
        }

            //-------------------------群聊请求-------------------------------
        case ENUM_MSG_TYPE_GROUP_CHAT_REQUEST:
        {
            char caName[32] ={'\0'};
            strncpy(caName, pdu->caData, 32);
            //那些好友在线
            QStringList onlineFriend = OperateDB::getInstance().handleFlushFriend(caName);
            QString tmp;
            //转发
            for(int i=0;i<onlineFriend.size();i++)
            {
                tmp=onlineFriend.at(i);
                MyTcpServer::getInstance().reSend(tmp.toStdString().c_str(),pdu);
            }
            break;
        }

            //--------------------------创建文件夹请求-------------
        case ENUM_MSG_TYPE_CREATE_DIR_REQUEST:
        {
            //判断当前目录存在与否
            QDir dir;
            QString strCurPath = QString("%1").arg((char*)(pdu->caMsg));
            bool ret = dir.exists(strCurPath);
            PDU *respdu = NULL;
            if(ret)
            {
                //当前目录存在
                //查看是否存在同名文件
                char caNewDir[32]={'\0'};
                memcpy(caNewDir,pdu->caData+32,32);
                QString strNewPath = strCurPath+"/"+caNewDir;
                qDebug()<<strNewPath;
                ret = dir.exists(strNewPath);

                qDebug()<<"--------->"<<ret;
                if(ret)
                {//同名文件
                    respdu=mkPDU(0);
                    respdu->uiMsgType = ENUM_MSG_TYPE_CREATE_DIR_RESPOND;
                    strcpy(respdu->caData,FILE_NAME_EXISTED);
                }
                else
                {
                    dir.mkdir(strNewPath);
                    respdu=mkPDU(0);
                    respdu->uiMsgType = ENUM_MSG_TYPE_CREATE_DIR_RESPOND;
                    strcpy(respdu->caData,CREATE_DIR_OK);
                }
            }
            else {//当前目录不存在
                respdu=mkPDU(0);
                respdu->uiMsgType = ENUM_MSG_TYPE_CREATE_DIR_RESPOND;
                strcpy(respdu->caData,DIR_NO_EXISTED);
            }
            //发送
            write((char*)respdu, respdu->uiPDULen);
            free(respdu);
            respdu =NULL;
            break;
        }


            //------------------------刷新文件夹请求----------------------
        case ENUM_MSG_TYPE_FLUSH_DIR_REQUEST:
        {
            char *pCurPath = new char[pdu->uiMsgLen];
            memcpy(pCurPath,pdu->caMsg,pdu->uiMsgLen);
            //遍历目录，获得文件信息
            QDir dir(pCurPath);
            QFileInfoList fileInfoList = dir.entryInfoList();

            //产生pdu
            int iFileCount = fileInfoList.size();
            PDU *respdu = mkPDU(sizeof (FileInfo)*iFileCount);
            respdu->uiMsgType = ENUM_MSG_TYPE_FLUSH_DIR_RESPOND;
            FileInfo *pFileInfo =NULL;
            QString strFileName;
            for(int i=0;i<iFileCount;i++)
            {
                //拷贝进去,跳到下一个结构体
                pFileInfo = (FileInfo*)(respdu->caMsg)+i;
                strFileName = fileInfoList[i].fileName();

                memcpy(pFileInfo->caFileName,strFileName.toStdString().c_str(),strFileName.size());
                //判断类型
                if(fileInfoList[i].isDir())
                {
                    pFileInfo->iFileType=0;//表示是个文件夹
                }
                else if(fileInfoList[i].isFile()) {
                    pFileInfo->iFileType =1;//常规文件
                }
            }
            //发送
            write((char*)respdu, respdu->uiPDULen);
            free(respdu);
            respdu =NULL;
            break;
        }


            //------------------------删除目录请求--------------------------
        case ENUM_MSG_TYPE_DELETE_DIR_REQUEST:
        {
            //拼接路径
            char caName[32] = {'\0'};
            strcpy(caName,pdu->caData);
            //产生一块空间，将传过来的路径拷贝出来
            char *pPath = new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            //拼接成一条完整的路径
            QString strPath = QString("%1/%2").arg(pPath).arg(caName);
            //验证
            //        qDebug()<<strPath;

            QFileInfo fileInfo(strPath);
            bool ret = false;
            if(fileInfo.isDir())
            {//是个文件夹
                QDir dir;
                dir.setPath(strPath);
                //removeRecursively删除路径，并且包括里面的文件.rmdir只能删除一个空的文件夹
                ret = dir.removeRecursively();
            }
            else if(fileInfo.isFile())
            {//常规文件，就不删除了
                ret =false;
            }
            PDU *respdu =NULL;
            if(ret)
            {
                //删除成功
                respdu=mkPDU(strlen(DELETE_DIR_OK)+1);
                respdu->uiMsgType=ENUM_MSG_TYPE_DELETE_DIR_RESPOND;
                memcpy(respdu->caData,DELETE_DIR_OK,strlen(DELETE_DIR_OK));
            }
            else {
                //删除失败
                respdu=mkPDU(strlen(DELETE_DIR_FAILED)+1);
                respdu->uiMsgType=ENUM_MSG_TYPE_DELETE_DIR_RESPOND;
                memcpy(respdu->caData,DELETE_DIR_FAILED,strlen(DELETE_DIR_FAILED));
            }

            //发送
            write((char*)respdu, respdu->uiPDULen);
            free(respdu);
            respdu =NULL;

            break;
        }

            //-----------------------重命名文件---------------------
        case ENUM_MSG_TYPE_RENAME_FILE_REQUEST:
        {
            char caOldName[32] = {'\0'};
            char caNewName[32] = {'\0'};
            strncpy(caOldName,pdu->caData,32);
            strncpy(caNewName,pdu->caData+32,32);
            //产生一块空间，将传过来的路径拷贝出来
            char *pPath = new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            //拼接成新旧两条路径
            QString strOldPath = QString("%1/%2").arg(pPath).arg(caOldName);
            QString strNewPath = QString("%1/%2").arg(pPath).arg(caNewName);
            qDebug()<<strOldPath;
            qDebug()<<strNewPath;
            QDir dir;
            bool ret =  dir.rename(strOldPath,strNewPath);
            PDU *respdu = mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_RENAME_FILE_RESPOND;
            if(ret)
            {
                //重命名成功
                memcpy(respdu->caData,RENAME_FILE_OK,strlen(RENAME_FILE_OK));
            }
            else {
                //重命名失败
                memcpy(respdu->caData,RENAME_FILE_FAILED,strlen(RENAME_FILE_FAILED));
            }
            //发送
            write((char*)respdu, respdu->uiPDULen);
            free(respdu);
            respdu =NULL;
            break;
        }

            //----------------------------进入文件夹--------------------
        case ENUM_MSG_TYPE_ENTER_DIR_REQUEST:
        {
            char caEnterName[32] = {'\0'};
            strncpy(caEnterName,pdu->caData,32);
            //产生一块空间，将传过来的路径拷贝出来
            char *pPath = new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);

            QString strPath = QString("%1/%2").arg(pPath).arg(caEnterName);
            qDebug()<<strPath;

            //判断是路径还是唱常规文件
            QFileInfo fileInfo(strPath);
            PDU *respdu =NULL;
            //判断类型
            if(fileInfo.isDir())
            {
                QDir dir(strPath);
                QFileInfoList fileInfoList = dir.entryInfoList();

                //产生pdu
                int iFileCount = fileInfoList.size();
                PDU *respdu = mkPDU(sizeof (FileInfo)*iFileCount);
                respdu->uiMsgType = ENUM_MSG_TYPE_FLUSH_DIR_RESPOND;
                FileInfo *pFileInfo =NULL;
                QString strFileName;
                for(int i=0;i<iFileCount;i++)
                {
                    //拷贝进去,跳到下一个结构体
                    pFileInfo = (FileInfo*)(respdu->caMsg)+i;
                    strFileName = fileInfoList[i].fileName();

                    memcpy(pFileInfo->caFileName,strFileName.toStdString().c_str(),strFileName.size());
                    //判断类型
                    if(fileInfoList[i].isDir())
                    {
                        pFileInfo->iFileType=0;//表示是个文件夹
                    }
                    else if(fileInfoList[i].isFile()) {
                        pFileInfo->iFileType =1;//常规文件
                    }
                }
                //发送
                write((char*)respdu, respdu->uiPDULen);
                free(respdu);
                respdu =NULL;
            }
            else if(fileInfo.isFile()) {
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ENTER_DIR_RESPOND;
                strcpy(respdu->caData,ENTERE_DIR_FAILED);

                write((char*)respdu, respdu->uiPDULen);
                free(respdu);
                respdu =NULL;
            }
            break;
        }
            //---------------上传文件--------------------
        case ENUM_MSG_TYPE_UPLOAD_FILE_REQUEST:
        {
            char caFileName[32] = {'\0'};
            qint64  fileSize =0;
            //将文件名字提取出来
            sscanf(pdu->caData, "%s %lld", caFileName,&fileSize);
            //产生一块空间，将传过来的路径拷贝出来
            char *pPath = new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            QString strPath = QString("%1/%2").arg(pPath).arg(caFileName);
            qDebug()<<strPath;

            //释放空间
            delete [] pPath;
            pPath = NULL;

            //根据拼接的路径将文件打开
            m_file.setFileName(strPath);
            //以只写的方式打开，如果这个文件不存在的话就会创建这个文件
            if(m_file.open(QIODevice::WriteOnly))
            {
                m_bUpload = true;
                m_iTotal =fileSize;
                m_iReceived = 0;
            }

            break;
        }
            //------------删除常规文件--------------------------
        case ENUM_MSG_TYPE_DELETE_FILE_REQUEST:
        {
            //拼接路径
            char caName[32] = {'\0'};
            strcpy(caName,pdu->caData);
            //产生一块空间，将传过来的路径拷贝出来
            char *pPath = new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            //拼接成一条完整的路径
            QString strPath = QString("%1/%2").arg(pPath).arg(caName);
            //验证
            //        qDebug()<<strPath;

            QFileInfo fileInfo(strPath);
            bool ret = false;
            if(fileInfo.isDir())
            {//是个文件夹，就不删除了
                ret =false;
            }
            else if(fileInfo.isFile())
            {//常规文件,删除
                QDir dir;
                //与删除目录的方式不一样哦
                ret = dir.remove(strPath);
            }
            PDU *respdu =NULL;
            if(ret)
            {
                //删除成功
                respdu=mkPDU(strlen(DELETE_FILE_OK)+1);
                respdu->uiMsgType=ENUM_MSG_TYPE_DELETE_FILE_RESPOND;
                memcpy(respdu->caData,DELETE_FILE_OK,strlen(DELETE_FILE_OK));
            }
            else {
                //删除失败
                respdu=mkPDU(strlen(DELETE_FILE_FAILED)+1);
                respdu->uiMsgType=ENUM_MSG_TYPE_DELETE_FILE_RESPOND;
                memcpy(respdu->caData,DELETE_FILE_FAILED,strlen(DELETE_FILE_FAILED));
            }

            //发送
            write((char*)respdu, respdu->uiPDULen);
            free(respdu);
            respdu =NULL;
            break;
        }

            //-----------下载文件--------------------------
        case ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST:
        {
            //先把路径名字得到
            char caFileName[32] = {'\0'};
            strcpy(caFileName,pdu->caData);
            //产生一块空间，将传过来的路径拷贝出来
            char *pPath = new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            QString strPath = QString("%1/%2").arg(pPath).arg(caFileName);
            qDebug()<<strPath;
            //释放空间
            delete [] pPath;
            pPath = NULL;

            //服务器给回复
            //先发送一个大小
            QFileInfo fileinfo(strPath);
            qint64 filesize = fileinfo.size();
            PDU *respdu =mkPDU(0);
            respdu->uiMsgType = ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND;
            sprintf(respdu->caData,"%s %lld",caFileName,filesize);
            //发送给客户端
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu = NULL;
            m_file.setFileName(strPath);
            m_file.open(QIODevice::ReadOnly);
            m_pTimer->start(1000);
            break;
        }

            //-----------分享文件--------------------------
        case ENUM_MSG_TYPE_SHARE_FILE_REQUEST:
        {
            char caSendName[32] = {'\0'};
            int num = 0;
            sscanf(pdu->caData, "%s%d", caSendName, &num);
            int size = num*32;
            PDU  *respdu = mkPDU(pdu->uiMsgLen-size);
            respdu->uiMsgType =ENUM_MSG_TYPE_SHARE_FILE_NOTE;
            strcpy(respdu->caData,caSendName);
            memcpy(respdu->caMsg, (char*)(pdu->caMsg)+size, pdu->uiMsgLen-size);
            //通知给谁
            char caReceName[32] = {'\0'};
            for(int i=0;i<num;i++)
            {
                memcpy(caReceName, (char*)(pdu->caMsg)+i*32, 32);
                MyTcpServer::getInstance().reSend(caReceName, respdu);
            }
            free(respdu);
            respdu=NULL;

            respdu=mkPDU(0);
            respdu->uiMsgType = ENUM_MSG_TYPE_SHARE_FILE_RESPOND;
            strcpy(respdu->caData, SHARE_FILE_OK);
            write((char*)respdu, respdu->uiPDULen);

            free(respdu);
            respdu=NULL;

            break;
        }

        case ENUM_MSG_TYPE_SHARE_FILE_NOTE_RESPOND:
        {
            QString strRecvPath = QString("./%1").arg(pdu->caData);
            //共享者文件路径
            QString strShareFilePath = QString("%1").arg((char*)(pdu->caMsg));

            //拼接名字
            int index = strShareFilePath.lastIndexOf('/');
            QString strFileName = strShareFilePath.right(strShareFilePath.size()-index-1);
            strRecvPath =strRecvPath +'/' +strFileName;
            //拷贝文件
            QFileInfo fileinfo(strShareFilePath);
            if(fileinfo.isFile())
            {
                QFile::copy(strShareFilePath,strRecvPath);
            }
            else if(fileinfo.isDir())
            {
                copyDir(strShareFilePath,strRecvPath);
            }
            break;
        }

            //-----------------移动文件---------------
        case ENUM_MSG_TYPE_MOVE_FILE_REQUEST:
        {
            //两个路径大小
            char caFileName[32] = {'\0'};
            int srclen =0;
            int destlen =0;
            sscanf(pdu->caData, "%d%d%s", &srclen, &destlen, caFileName);

            //产生空间，将地址拷贝出来
            char *pSrcPath = new char[srclen+1];
            //+32从一个路径移动到另一个路径，移动时候必须在目的路径里面只当他的名字
            char *pDestPath = new char[destlen+1+32];
            memset(pSrcPath, '\0', srclen+1); //清空空间
            memset(pDestPath, '\0', destlen+1+32);

            memcpy(pSrcPath, pdu->caMsg, srclen);
            memcpy(pDestPath, (char*)(pdu->caMsg)+(srclen+1), destlen);

            PDU *respdu =mkPDU(0);
            respdu->uiMsgType = ENUM_MSG_TYPE_MOVE_FILE_RESPOND;
            QFileInfo fileinfo(pDestPath);
            if(fileinfo.isDir())
            {
                strcat(pDestPath, "/");
                strcat(pDestPath, caFileName);

                bool ret = QFile::rename(pSrcPath, pDestPath);
                if(ret)
                {
                    strcpy(respdu->caData, MOVE_FILE_OK);

                }
                else {
                    strcpy(respdu->caData, COMMON_ERROR);
                }
            }
            else if (fileinfo.isFile()) {
                strcpy(respdu->caData, MOVE_FILE_FAILED);
            }
            write((char*)respdu, respdu->uiPDULen);

            free(respdu);
            respdu=NULL;

            break;
        }
        default:
            break;
        }
        free (pdu);
        pdu =NULL;
    }
    else {

        //接收数据
        PDU *respdu = NULL;
        respdu =mkPDU(0);
        respdu->uiMsgType = ENUM_MSG_TYPE_UPLOAD_FILE_RESPOND;
        QByteArray buff = readAll();//接收读到的数据
        m_file.write(buff);//将读到的数据写道buff里面去
        m_iReceived+=buff.size();
        if(m_iTotal==m_iReceived)
        {//接收数据结束了
            m_file.close();
            m_bUpload = false;
            strcpy(respdu->caData,UPLOAD_FILE_OK);
            //发送给客户端
            write((char*)respdu, respdu->uiPDULen);
            free(respdu);
            respdu =NULL;
        }
        else if ((m_iTotal<m_iReceived))
        {
            m_file.close();
            m_bUpload = false;
            strcpy(respdu->caData,UPLOAD_FILE_FAILED);
            //发送给客户端
            write((char*)respdu, respdu->uiPDULen);
            free(respdu);
            respdu =NULL;
        }
    }
}

void MyTcpSocket::clientOffline()
{
    //将在线状态设置为非在线状态
    //将数据库的状态做修改
    OperateDB::getInstance().handleOffline(m_strName.toStdString().c_str());
    //删除链表的socket
    emit offline(this);
}

void MyTcpSocket::sendFileToClient()
{
    char *pData =new char[4096];
    qint64 ret =0;
    while (true) {
        ret = m_file.read(pData, 4096);
        if(ret>0 &&ret <=4096)
        {
            write(pData,ret);
        }
        else if (0==ret) {//所有文件都读取出来，并且发送完了
            m_file.close();
            break;
        }
        else if (ret<0) {
            qDebug()<<"发送文件内容给客户端过程中失败";
            m_file.close();
            break;
        }
    }
    delete [] pData;
    pData = NULL;
}



















