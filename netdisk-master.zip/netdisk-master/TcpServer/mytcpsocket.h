#ifndef MYTCPSOCKET_H
#define MYTCPSOCKET_H
#include <QTcpSocket>
#include "protocal.h"
#include "operatedb.h"
#include <QDir>
#include <QFile>
#include <QTimer>
class MyTcpSocket : public QTcpSocket
{
    Q_OBJECT
public:
    MyTcpSocket();
    QString getName();
    //分享文件——文件夹的拷贝
    void copyDir(QString strSrcDir, QString strDestDir);

signals:
    //下线_放地址
    void offline(MyTcpSocket *mysocket);

private slots:
    //定义槽函数
    void recvMsg();
    //用来处理客户端下线
    void clientOffline();
    //发送文件数据给客户端
    void sendFileToClient();


private:
    QString m_strName;

    QFile m_file;
    //文件总的大小
    qint64 m_iTotal;
    qint64 m_iReceived;//每一次接受了多少文件
    bool m_bUpload; //现在处于上传文件状态还是其他状态
    QTimer *m_pTimer;
};

#endif // MYTCPSOCKET_H
