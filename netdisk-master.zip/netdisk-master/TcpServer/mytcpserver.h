#ifndef MYTCPSERVER_H
#define MYTCPSERVER_H

#include <QTcpServer>
#include <QList>
#include "mytcpsocket.h"
#include <QFile>
class MyTcpServer : public QTcpServer
{
    //为了让他支持信号槽，必须在类的最开始写Q_OBJECT，作为QTcpServer的基类
    Q_OBJECT
public:

    MyTcpServer();
    //单例模式
    static MyTcpServer &getInstance();
    void incomingConnection(qintptr socketDescriptor);
    //获得socket，转发获取
    void reSend(const char *pername, PDU *pdu);

public slots:
    void deleteSocket(MyTcpSocket *mysocket);


private:
    QList <MyTcpSocket*> m_tcpSocketList;

};

#endif // MYTCPSERVER_H
