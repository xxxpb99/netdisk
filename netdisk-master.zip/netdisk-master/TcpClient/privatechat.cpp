#include "privatechat.h"
#include "ui_privatechat.h"
#include "protocal.h"
#include "tcpclient.h"
#include <QMessageBox>
PrivateChat::PrivateChat(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PrivateChat)
{
    ui->setupUi(this);
}

PrivateChat::~PrivateChat()
{
    delete ui;
}

PrivateChat &PrivateChat::getInstance()
{
    static PrivateChat instance;
    return instance;
}

void PrivateChat::setChatName(QString strName)
{
    m_strChatName = strName;
    m_strLoginName=TcpClient::getinstance().loginName();
}

void PrivateChat::updateMsg(const PDU *pdu)
{
    if(NULL==pdu)
    {
        return;
    }
    char caSendName[32]={'\0'};
    memcpy(caSendName,pdu->caData,32);
    QString strMsg = QString("%1 says: %2").arg(caSendName).arg((char*)(pdu->caMsg));
    //信息显示在界面上面
    ui->showMsg_te->append(strMsg);
}

void PrivateChat::on_sendMSG_pb_clicked()
{
    //获得输入框的信息
    QString strMsg = ui->inputMsg_le->text();
    //发送完之后直接clear掉
    ui->inputMsg_le->clear();
    if(!strMsg.isEmpty())
    {
        //+1是后面追加一个\0
        PDU *pdu =mkPDU(strMsg.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_PRIVATE_CHAT_REQUEST;
        //将双方的名字拷贝进去
        memcpy(pdu->caData,m_strLoginName.toStdString().c_str(),m_strLoginName.size());
        memcpy(pdu->caData+32,m_strChatName.toStdString().c_str(),m_strChatName.size());
        //将聊天信息拷贝进去
        strcpy((char*)(pdu->caMsg),strMsg.toStdString().c_str());
        TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;

    }
    else
    {
        QMessageBox::warning(this,"私聊","发送的聊天信息不能为空");
    }
}
