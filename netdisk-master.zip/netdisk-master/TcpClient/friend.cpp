#include "friend.h"
#include "protocal.h"
#include "tcpclient.h"
#include <QInputDialog>
#include <QDebug>
#include "privatechat.h"
#include <QMessageBox>
Friend::Friend(QWidget *parent) : QWidget(parent)
{
    m_pShowMsgTE = new QTextEdit;
    m_pFriendListWidget = new QListWidget;
    m_pInputMsgLE = new QLineEdit;

    m_pDelFriendPB = new QPushButton ("删除好友");
    m_pFlushFriendPB = new QPushButton ("刷新好友");
    m_pShowOnlineUsrPB= new QPushButton ("显示在线用户");
    m_pSearchUsrPB= new QPushButton("查找用户");
    m_pMsgSendPB= new QPushButton("信息发送");
    m_pPrivateChatPB= new QPushButton("私聊");

    QVBoxLayout *pRightPBVBL = new QVBoxLayout;
    pRightPBVBL->addWidget(m_pDelFriendPB);
    pRightPBVBL->addWidget(m_pFlushFriendPB);
    pRightPBVBL->addWidget(m_pShowOnlineUsrPB);
    pRightPBVBL->addWidget(m_pSearchUsrPB);
    pRightPBVBL->addWidget(m_pPrivateChatPB);

    QHBoxLayout *pTopHBL = new QHBoxLayout;
    pTopHBL->addWidget(m_pShowMsgTE);
    pTopHBL->addWidget(m_pFriendListWidget);
    pTopHBL->addLayout(pRightPBVBL);

    QHBoxLayout *PMsgHBL = new QHBoxLayout;
    PMsgHBL->addWidget(m_pInputMsgLE);
    PMsgHBL->addWidget(m_pMsgSendPB);

    m_pOnline = new Online;

    QVBoxLayout *pMain = new QVBoxLayout;
    pMain->addLayout(pTopHBL);
    pMain->addLayout(PMsgHBL);
    pMain->addWidget(m_pOnline);
    m_pOnline->hide();

    setLayout(pMain);

    connect(m_pShowOnlineUsrPB, SIGNAL(clicked(bool)) , this, SLOT(showOnline()));

    //关联查找用户信号槽
    connect(m_pSearchUsrPB, SIGNAL(clicked(bool)), this, SLOT(searchUser()));

    //关联刷新好友信号槽
    connect(m_pFlushFriendPB,  SIGNAL(clicked(bool)), this, SLOT(flushFriend()));

    //关联删除好友槽函数
    connect(m_pDelFriendPB,SIGNAL(clicked(bool)), this, SLOT(deleteFriend()));

    //关联私聊好友槽函数
    connect(m_pPrivateChatPB,SIGNAL(clicked(bool)), this, SLOT(privateChat()));

    //关联私聊好友槽函数
    connect(m_pMsgSendPB,SIGNAL(clicked(bool)), this, SLOT(groupChat()));
}

void Friend::ShowAllOnlineUser(PDU *pdu)
{
    if(NULL==pdu){
        return;
    }
    m_pOnline->showUsr(pdu);
}

void Friend::updateFriendList(PDU *pdu)
{
    if(NULL==pdu)
    {
        return;
    }
    //先判断里面有多少个人
    uint uiSize =pdu->uiMsgLen/32;
    char caName[32]={'\0'};
    for(uint i=0;i<uiSize;i++)
    {
        memcpy(caName,(char*)(pdu->caMsg)+i*32,32);
        m_pFriendListWidget->addItem(caName);
    }
}

void Friend::updateGroupMsg(PDU *pdu)
{
    QString strMsg = QString("%1 says: %2").arg(pdu->caData).arg((char*)(pdu->caMsg));
    m_pShowMsgTE->append(strMsg);
}

QListWidget *Friend::getFriendlist()
{
    return  m_pFriendListWidget;
}

void Friend::showOnline()
{
    //如果m_ponline是隐藏的，我们将他打开
    if(m_pOnline->isHidden()){
        m_pOnline->show();
        PDU *pdu =mkPDU(0);//产生协议数据单元
        pdu->uiMsgType = ENUM_MSG_TYPE_ALL_ONLINE_REQUEST;
        //将请求信息发送出去
        TcpClient::getinstance().getTcpSocket().write((char*)pdu, pdu->uiPDULen);
        //释放
        free(pdu);
        pdu = NULL;
    }
    else {
        m_pOnline->hide();
    }
}

void Friend::searchUser()
{
    //搜索用户的时候，会弹出一个对话框来
    m_strSearchName = QInputDialog::getText(this, "搜索", "用户名：");
    //将名字打印出来
    if(!m_strSearchName.isEmpty()){
        qDebug()<<m_strSearchName;
        PDU *pdu =mkPDU(0);
        memcpy(pdu->caData, m_strSearchName.toStdString().c_str(),m_strSearchName.size());
        pdu->uiMsgType = ENUM_MSG_TYPE_SEARCH_USER_REQUEST;
        TcpClient::getinstance().getTcpSocket().write((char*)pdu, pdu->uiPDULen);
        free(pdu);
        pdu = NULL;
    }
}

void Friend::flushFriend()
{
    //或者登录的名字
    QString strName = TcpClient::getinstance().loginName();
    //进行打包
    //产生pdu
    PDU *pdu =mkPDU(0);
    pdu->uiMsgType=ENUM_MSG_TYPE_FLUSH_FRIEND_REQUEST;
    memcpy(pdu->caData,strName.toStdString().c_str(),strName.size());

    //通过socket将pdu发送给服务器
    TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
    free(pdu);
    pdu=NULL;
}

void Friend::deleteFriend()
{
    if(NULL != m_pFriendListWidget->currentItem())
    {
        //通过ListWidget里获得当前的Item，再通过Item获得当前的文本
        QString strFriendName = m_pFriendListWidget->currentItem()->text();
        PDU *pdu =mkPDU(0);
        pdu->uiMsgType=ENUM_MSG_TYPE_DELETE_FRIEND_REQUEST;
        QString strSelfName = TcpClient::getinstance().loginName();
        memcpy(pdu->caData,strSelfName.toStdString().c_str(),strSelfName.size());
        memcpy(pdu->caData+32,strFriendName.toStdString().c_str(),strFriendName.size());

        //通过socket将pdu发送给服务器
        TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
}

void Friend::privateChat()
{
    if(NULL != m_pFriendListWidget->currentItem())
    {
        QString strChatName = m_pFriendListWidget->currentItem()->text();
        PrivateChat::getInstance().setChatName(strChatName);
        //显示窗口
        if(PrivateChat::getInstance().isHidden())
        {
            PrivateChat::getInstance().show();
        }
    }
    else
    {
        QMessageBox::warning(this,"私聊","请选择私聊的对象");
    }
}

void Friend::groupChat()
{
    QString strMsg = m_pInputMsgLE->text();
    if(!strMsg.isEmpty())
    {
        PDU *pdu =mkPDU(strMsg.size()+1);
        pdu->uiMsgType= ENUM_MSG_TYPE_GROUP_CHAT_REQUEST;
        QString strName = TcpClient::getinstance().loginName();
        strncpy(pdu->caData,strName.toStdString().c_str(),strName.size());

        strncpy((char*)(pdu->caMsg),strMsg.toStdString().c_str(),strMsg.size());
        //发送给服务器
        TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
    }
    else {
        QMessageBox::warning(this,"群聊","信息不能为空");
    }
}











