#ifndef BOOK_H
#define BOOK_H

#include <QWidget>
#include <QListWidget>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include "protocal.h"
class Book : public QWidget
{
    Q_OBJECT
public:
    explicit Book(QWidget *parent = nullptr);
    //更新文件列表
    void updateFileList(const PDU *pdu);
    void clearEnterDir();
    //设置download的状态
    void setDownloadStatus(bool status);
    bool getDownloadStatus();
    //获得共享文件名称
    QString getShowFileName();

    //获取下载文件总的大小
    qint64 m_iTotal;
    //现在收到了多少
    qint64 m_Recived;
    //获得保存路径
    QString getSaveFilePath();
signals:
public slots:
    //创建文件夹
    void createDir();
    //刷新文件夹
    void flushDir();
    //删除文件夹
    void deleteDir();
    //重命名文件夹
    void renameFile();
    //进入文件夹
    void enterDir(const QModelIndex &index);
    QString enterDir();
    //返回上一级
    void returnPre();
    //上传文件
    void uploadFile();
    //创建定时器
    void uploadFileData();
    //删除常规文件
    void delRegeFile();
    //下载文件
    void downloadFile();
    //分享文件
    void shareFile();
    //移动文件
    void moveFile();
    //移动文件目标目录槽函数
    void selectDestDir();

private:
    //显示文件名字的列表
    QListWidget *m_pBookListW;
    //操作文件的按钮
    QPushButton *m_pReturnPB;
    QPushButton *m_pCreateDirPB;
    QPushButton *m_pDelDirPB;
    QPushButton *m_pRenamePB;
    QPushButton *m_pFlushFilePB;
    QPushButton *m_pUpLoadPB;
    QPushButton *m_pDownLoadPB;
    QPushButton *m_pDelFilePB;
    QPushButton *m_pShareFilePB;
    //移动文件
    QPushButton *m_pMoveFilePB;
    //选择要移动到那个文件夹
    QPushButton *m_pSelectDirPB;

    QString m_strEnterDir;

    QString m_strUploadFilePath;
    QTimer *m_pTimer;
    //保存下载路径
    QString m_strSaveFilePath;
    //定义变量，设置是否正处于下载的状态
    bool m_bDownload;
    //文件名
    QString m_strShareFileName;
    //保存要移动的文件名
    QString m_strMoveFileName;
    //将路径和文件名拼接成一个访问路径
    QString m_strMoveFilePath;

    QString m_strDestDir;

};

#endif // BOOK_H
