#include "sharefile.h"
#include "tcpclient.h"

ShareFile::ShareFile(QWidget *parent) : QWidget(parent)
{
    //全选
    m_pSelectAllPB = new QPushButton("全选");
    //取消
    m_pCancelSelectPB = new QPushButton("取消选择");
    //确定
    m_pOKPB = new QPushButton("确定");
    //取消分享
    m_pCancelPB = new QPushButton("取消");
    //中间显示好友的区域
    m_pSA = new QScrollArea;
    m_pFriendW = new QWidget;
    m_FriendWVBL = new QVBoxLayout(m_pFriendW);
    m_pButtonGroup = new QButtonGroup(m_pFriendW);
    m_pButtonGroup->setExclusive(false);

    QHBoxLayout *pTopHBL = new QHBoxLayout;
    pTopHBL->addWidget(m_pSelectAllPB);
    pTopHBL->addWidget(m_pCancelSelectPB);
    pTopHBL->addStretch();//弹簧

    QHBoxLayout *pDownHBL = new QHBoxLayout;
    pDownHBL->addWidget(m_pOKPB);
    pDownHBL->addWidget(m_pCancelPB);

    QVBoxLayout *pMainVBL = new QVBoxLayout;
    pMainVBL->addLayout(pTopHBL);
    pMainVBL->addWidget(m_pSA);
    pMainVBL->addLayout(pDownHBL);

    setLayout(pMainVBL);

    //关联取消选择信号槽
    connect(m_pCancelSelectPB,SIGNAL(clicked(bool))
            ,this, SLOT(cancleSelect()));

    //关联全部选择信号槽
    connect(m_pSelectAllPB,SIGNAL(clicked(bool))
            ,this, SLOT(allSelect()));

    //关联确定分享信号槽
    connect(m_pOKPB,SIGNAL(clicked(bool))
            ,this, SLOT(okShare()));

    //关联取消分享信号槽
    connect(m_pCancelPB,SIGNAL(clicked(bool))
            ,this, SLOT(cancleShare()));



}

ShareFile &ShareFile::getinstance()
{
    static ShareFile instance;
    return instance;
}

void ShareFile::test()
{
    QVBoxLayout *p = new QVBoxLayout(m_pFriendW);
    QCheckBox *pCB = NULL;
    for(int i=0;i<15;i++)
    {
        pCB = new QCheckBox("jack");
        p->addWidget(pCB);
        m_pButtonGroup->addButton(pCB);
    }
    m_pSA->setWidget(m_pFriendW);
}

void ShareFile::updateFriend(QListWidget *pFriendList)
{
    if(NULL == pFriendList)
    {
        return;
    }
    QAbstractButton *tmp = NULL;
    //刷新掉以前的
    QList<QAbstractButton*>preFriendList = m_pButtonGroup->buttons();
    for(int i=0;i<preFriendList.size();i++)
    {
        tmp = preFriendList[i];
        m_FriendWVBL->removeWidget(tmp);
        m_pButtonGroup->removeButton(tmp);
        preFriendList.removeOne(tmp);
        delete tmp;
        tmp = NULL;
    }
    //将新的放进来
    QAbstractButton *pCB = NULL;
    for(int i=0;i<pFriendList->count();i++)
    {
        pCB = new QCheckBox(pFriendList->item(i)->text());
        m_FriendWVBL->addWidget(pCB);
        m_pButtonGroup->addButton(pCB);
    }
    m_pSA->setWidget(m_pFriendW);
}

//分享文件取消选择
void ShareFile::cancleSelect()
{
    //获得选择的checkbox
    QList<QAbstractButton*> cbList = m_pButtonGroup->buttons();
    //循环遍历list
    for(int i=0; i<cbList.size(); i++)
    {
        if(cbList[i]->isChecked())
        {
            cbList[i]->setChecked(false);
        }
    }
}

//分享文件全选
void ShareFile::allSelect()
{
    //获得选择的checkbox
    QList<QAbstractButton*> cbList = m_pButtonGroup->buttons();
    //循环遍历list
    for(int i=0; i<cbList.size(); i++)
    {
        if(!cbList[i]->isChecked())
        {
            cbList[i]->setChecked(true);
        }
    }
}

//确定分享文件
void ShareFile::okShare()
{
    //谁分享的
    QString strName =  TcpClient::getinstance().loginName();
    //当前的路径
    QString strCurPath = TcpClient::getinstance().curPath();
    //获得共享的文件名
    QString strShareFileName = OpeWidget::getInstance().getBook()->getShowFileName();

    QString strPath = strCurPath +"/"+strShareFileName;

    //获得接收者
    //获得选择的checkbox
    QList<QAbstractButton*> cbList = m_pButtonGroup->buttons();
    int num =0;
    //循环遍历list
    for(int i=0; i<cbList.size(); i++)
    {
        if(cbList[i]->isChecked())
        {
            num++;
        }
    }
    PDU *pdu = mkPDU(32*num+strPath.size()+1);
    pdu->uiMsgType = ENUM_MSG_TYPE_SHARE_FILE_REQUEST;
    sprintf(pdu->caData, "%s %d", strName.toStdString().c_str(),num);
    int j =0;
    for(int i=0;i<cbList.size();i++)
    {
        if(cbList[i]->isChecked())
        {
            memcpy((char*)(pdu->caMsg)+j*32, cbList[i]->text().toStdString().c_str(), cbList[i]->text().size());
            j++;
        }
    }
    //将路径拷贝进去
    memcpy((char*)(pdu->caMsg)+num*32, strPath.toStdString().c_str(), strPath.size());

    TcpClient::getinstance().getTcpSocket().write((char*)pdu, pdu->uiPDULen);
    free(pdu);
    pdu=NULL;
}

//取消分享文件
void ShareFile::cancleShare()
{
    hide();
}














