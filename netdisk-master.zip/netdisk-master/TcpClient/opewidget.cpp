#include "opewidget.h"

OpeWidget::OpeWidget(QWidget *parent) : QWidget(parent)
{
    m_pListW = new QListWidget(this);
    m_pListW->addItem("好友");
    m_pListW->addItem("图书");

    m_pFriend = new Friend;
    m_pBook = new Book;
    m_pSW = new QStackedWidget;
    //将好友和图书窗口加进去,当没有设置显示那个窗口的时候，默认显示第一个窗口
    m_pSW->addWidget(m_pFriend);
    m_pSW->addWidget(m_pBook);

    QHBoxLayout *PMain = new QHBoxLayout;
    PMain->addWidget(m_pListW);
    PMain->addWidget(m_pSW);

    setLayout(PMain);

    connect(m_pListW, SIGNAL(currentRowChanged(int)), m_pSW, SLOT(setCurrentIndex(int)));
}

OpeWidget &OpeWidget::getInstance()
{
    //产生一个静态的操作界面的对象。操作界面这个对象他是静态的，不管调用多少次这个函数，始终使用的都是这个instance
    static OpeWidget instance;
    return instance;
}

Friend *OpeWidget::getFriend()
{
    return m_pFriend;
}

Book *OpeWidget::getBook()
{
    return m_pBook;
}



