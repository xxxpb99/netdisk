#include "book.h"
#include "protocal.h"
#include "tcpclient.h"
#include <QInputDialog>
#include <QMessageBox>
#include <QFileDialog>
#include <QTimer>
#include "opewidget.h"
#include "sharefile.h"
#include <QListWidget>
Book::Book(QWidget *parent) : QWidget(parent)
{

    m_strEnterDir.clear();
    m_bDownload =false;
    m_pTimer = new QTimer;
    //显示文件名字的列表
    m_pBookListW = new QListWidget;
    //操作文件的按钮
    m_pReturnPB = new QPushButton("返回");
    m_pCreateDirPB= new QPushButton("创建文件夹");
    m_pDelDirPB= new QPushButton("删除文件夹");
    m_pRenamePB= new QPushButton("重命名文件");
    m_pFlushFilePB= new QPushButton("刷新文件");


    //通过布局放到界面上去
    QVBoxLayout *pDirVBL=new QVBoxLayout;
    pDirVBL->addWidget(m_pReturnPB);
    pDirVBL->addWidget(m_pCreateDirPB);
    pDirVBL->addWidget(m_pDelDirPB);
    pDirVBL->addWidget(m_pRenamePB);
    pDirVBL->addWidget(m_pFlushFilePB);


    m_pUpLoadPB= new QPushButton("上传文件");
    m_pDownLoadPB= new QPushButton("下载文件");
    m_pDelFilePB= new QPushButton("删除文件");
    m_pShareFilePB= new QPushButton("共享文件");
    m_pMoveFilePB = new QPushButton("移动文件");
    m_pSelectDirPB= new QPushButton("目标目录");
    //假如没有选择移动文件的话，将这个按键设置成灰的，选不了的
    m_pSelectDirPB->setEnabled(false);

    //通过布局放到界面上去
    QVBoxLayout *pFileVBL=new QVBoxLayout;
    pFileVBL->addWidget(m_pUpLoadPB);
    pFileVBL->addWidget(m_pDownLoadPB);
    pFileVBL->addWidget(m_pDelFilePB);
    pFileVBL->addWidget(m_pShareFilePB);
    pFileVBL->addWidget(m_pMoveFilePB);
    pFileVBL->addWidget(m_pSelectDirPB);


    QHBoxLayout *pMain = new QHBoxLayout;
    pMain->addWidget(m_pBookListW);
    pMain->addLayout(pDirVBL);
    pMain->addLayout(pFileVBL);

    setLayout(pMain);

    //关联创建文件夹
    connect(m_pCreateDirPB,SIGNAL(clicked(bool)),
            this, SLOT(createDir()));

    //关联刷新文件夹信号槽
    connect(m_pFlushFilePB,SIGNAL(clicked(bool)),
            this, SLOT(flushDir()));

    //关联删除文件夹信号槽
    connect(m_pDelDirPB,SIGNAL(clicked(bool)),
            this, SLOT(deleteDir()));

    //关联重命名文件夹信号槽
    connect(m_pRenamePB,SIGNAL(clicked(bool)),
            this, SLOT(renameFile()));

    //关联进入文件夹信号槽  doubleClicked双击
    connect(m_pBookListW,SIGNAL(doubleClicked(QModelIndex)),
            this, SLOT(enterDir(QModelIndex)));

    //关联返回上一级信号槽
    connect(m_pReturnPB,SIGNAL(clicked(bool)),
            this, SLOT(returnPre()));

    //关联上传文件信号槽
    connect(m_pUpLoadPB,SIGNAL(clicked(bool)),
            this, SLOT(delRegeFile()));

    //关联定时器信号槽
    connect(m_pTimer,SIGNAL(timeout()),
            this, SLOT(uploadFileData()));
    //关联删除常规文件槽函数
    connect(m_pDelFilePB, SIGNAL(clicked(bool)),
            this, SLOT(delRegeFile()));

    //关联下载文件槽函数
    connect(m_pDownLoadPB, SIGNAL(clicked(bool)),
            this, SLOT(downloadFile()));

    //关联分享文件槽函数
    connect(m_pShareFilePB, SIGNAL(clicked(bool)),
            this, SLOT(shareFile()));

    //关联移动文件槽函数
    connect(m_pMoveFilePB, SIGNAL(clicked(bool)),
            this, SLOT(moveFile()));

    //关联目标目录的槽函数
    connect(m_pSelectDirPB, SIGNAL(clicked(bool)),
            this, SLOT(selectDestDir()));
}

void Book::updateFileList(const PDU *pdu)
{
    if(NULL==pdu)
    {
        return;
    }
    FileInfo *pFileInfo =NULL;
    int iCount = pdu->uiMsgLen/sizeof (FileInfo);
    for(int i=0 ;i<iCount;i++)
    {
        pFileInfo =(FileInfo*)(pdu->caMsg)+i;
        qDebug()<<pFileInfo->caFileName<<pFileInfo->iFileType;
        QListWidgetItem *pItem = new QListWidgetItem;
        if(0==pFileInfo->iFileType)
        {
            pItem->setIcon(QIcon(QPixmap(":/map/dir.jpg")));
        }
        else if(1==pFileInfo->iFileType) {
            pItem->setIcon(QIcon(QPixmap(":/map/reg.png")));
        }
        pItem->setText(pFileInfo->caFileName);
        m_pBookListW->addItem(pItem);
    }

}

void Book::clearEnterDir()
{
    m_strEnterDir.clear();
}

void Book::setDownloadStatus(bool status)
{
    m_bDownload =status;
}

void Book::createDir()
{
    //获得文件夹名字
    QString strNewDir = QInputDialog::getText(this, "新建文件夹","新文件夹名字");
    if(!strNewDir.isEmpty())
    {
        //查看长度是否超过32
        if(strNewDir.size()>32)
        {
            QMessageBox::warning(this,"新建文件夹","新建文件夹名字不能超过32个字符");
        }
        else
        {
            QString strName = TcpClient::getinstance().loginName();
            QString strCurPath = TcpClient::getinstance().curPath();
            PDU *pdu =mkPDU(strCurPath.size()+1);
            //填充
            pdu->uiMsgType=ENUM_MSG_TYPE_CREATE_DIR_REQUEST;
            strncpy(pdu->caData,strName.toStdString().c_str(),strName.size());
            strncpy(pdu->caData+32,strNewDir.toStdString().c_str(),strNewDir.size());
            memcpy(pdu->caMsg,strCurPath.toStdString().c_str(),strCurPath.size());
            //发送给服务器
            TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
            free(pdu);
            pdu=NULL;
        }

    }

    else
    {
        QMessageBox::warning(this,"新建文件夹","新建文件夹名字不能为空");
    }
}

void Book::flushDir()
{

    QString strCurPath = TcpClient::getinstance().curPath();
    PDU *pdu =mkPDU(strCurPath.size()+1);
    pdu->uiMsgType=ENUM_MSG_TYPE_FLUSH_DIR_REQUEST;
    strncpy((char*)(pdu->caMsg),strCurPath.toStdString().c_str(),strCurPath.size());
    //发送给服务器
    TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
    free(pdu);
    pdu=NULL;
}

void Book::deleteDir()
{
    //获得当前所在的目录
    QString strCurPath = TcpClient::getinstance().curPath();
    //获得点击删除的文件
    QListWidgetItem *pItem =  m_pBookListW->currentItem();
    //判断
    if(NULL==pItem)
    {
        QMessageBox::warning(this,"删除文件","请选择要删除的文件");
    }
    else
    {
        //列表上面的文件名称
        QString strDelName = pItem->text();
        //路径太长了，放在caMsg里面，名字就放在caData里面
        PDU *pdu =mkPDU(strCurPath.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_DELETE_DIR_REQUEST;
        strncpy((char*)(pdu->caData),strDelName.toStdString().c_str(),strDelName.size());
        memcpy(pdu->caMsg,strCurPath.toStdString().c_str(),strCurPath.size());
        //发送给服务器
        TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
}

void Book::renameFile()
{
    //获得当前所在的目录
    QString strCurPath = TcpClient::getinstance().curPath();
    //获得点击重命名的文件
    QListWidgetItem *pItem =  m_pBookListW->currentItem();
    //判断
    if(NULL==pItem)
    {
        QMessageBox::warning(this,"重命名文件","请选择要重命名的文件");
    }
    else
    {
        //获得旧的文件名字
        QString strOldName = pItem->text();
        //获得新的的文件名字
        QString strNewName = QInputDialog::getText(this,"重命名文件","请输入新的文件名");
        if(!strNewName.isEmpty())
        {
            //存放
            //路径太长了，放在caMsg里面，名字就放在caData里面
            PDU *pdu =mkPDU(strCurPath.size()+1);
            pdu->uiMsgType=ENUM_MSG_TYPE_RENAME_FILE_REQUEST;
            strncpy(pdu->caData,strOldName.toStdString().c_str(),strOldName.size());
            strncpy(pdu->caData+32,strNewName.toStdString().c_str(),strNewName.size());
            memcpy(pdu->caMsg,strCurPath.toStdString().c_str(),strCurPath.size());

            //发送给服务器
            TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
            free(pdu);
            pdu=NULL;
        }
        else {
            QMessageBox::warning(this,"重命名文件","新文件名不能为空");
        }

    }
}

void Book::enterDir(const QModelIndex &index)
{
    //通过index获得双击的选项上面的内容
    QString strDirName = index.data().toString();
    m_strEnterDir = strDirName;
    //测试打印
    //qDebug()<<strDirName;
    QString strCurPath = TcpClient::getinstance().curPath();
    PDU *pdu =mkPDU(strCurPath.size()+1);
    pdu->uiMsgType=ENUM_MSG_TYPE_ENTER_DIR_REQUEST;
    strncpy(pdu->caData,strDirName.toStdString().c_str(),strDirName.size());
    memcpy(pdu->caMsg,strCurPath.toStdString().c_str(),strCurPath.size());
    //发送给服务器
    TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
    free(pdu);
    pdu=NULL;
}

QString Book::enterDir()
{
    return m_strEnterDir;
}

void Book::returnPre()
{
    //判断当前目录是不是顶层目录
    QString strCurPath = TcpClient::getinstance().curPath();
    QString strRootPath = "./"+TcpClient::getinstance().loginName();
    if(strCurPath==strRootPath)
    {
        QMessageBox::warning(this, "返回上一级","返回失败，已经在最开始的文件夹目录中！");
    }
    else
    {
        //  "./aa/bb/cc"   -----> "./aa/bb"
        int index = strCurPath.lastIndexOf('/');
        strCurPath.remove(index,strCurPath.size()-index);
        qDebug()<<"return-->"<<strCurPath;
        //将新的路径保存到当前目录里面
        TcpClient::getinstance().setCurPath(strCurPath);

        clearEnterDir();//将进入的子文件夹给清除掉，因为上一层的话，要显示上一层的信息，使用刷新的功能就可以了

        flushDir();
    }
}

void Book::uploadFile()
{
    //当前路径
    QString strCurPath = TcpClient::getinstance().curPath();
    //选择上传文件
    //QFileDialog::getOpenFileName();会弹出一个窗口来，类似于打开文件
    m_strUploadFilePath = QFileDialog::getOpenFileName();
    //qDebug()<<strUploadFilePath;
    //将名字提取出来
    if(!m_strUploadFilePath.isEmpty())
    {
        // aa/bb/cc 5 8
        int index = m_strUploadFilePath.lastIndexOf('/');
        QString strFileName =m_strUploadFilePath.right(m_strUploadFilePath.size()-index-1);
        //qDebug()<<strFileName;
        //将数据封装到PDU里面
        QFile file(m_strUploadFilePath);
        qint64 filesize = file.size();//获得文件大小
        PDU *pdu =mkPDU(strCurPath.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_UPLOAD_FILE_REQUEST;
        memcpy(pdu->caMsg, strCurPath.toStdString().c_str(),strCurPath.size());
        //"%s %lld" %s文件名 lld文件大小long long 64
        sprintf(pdu->caData,"%s %lld", strFileName.toStdString().c_str(),filesize);
        //发送
        //发送给服务器
        TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;

        //添加一个定时器防止数据粘连
        m_pTimer->start(1000);

    }
    else {
        QMessageBox::warning(this, "上传文件","上传文件名字不能为空！");
    }
}

void Book::uploadFileData()
{
    m_pTimer->stop();//先关了，要不然他会重新计时
    QFile file(m_strUploadFilePath);
    if(!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this,"上传文件", "打开文件失败");
        return;
    }

    char *pBuffer = new char[4096];
    qint64 ret =0;
    while (true) {
        ret = file.read(pBuffer,4096);
        if(ret>0&&ret<=4096)
        {
            //读到了数据
            TcpClient::getinstance().getTcpSocket().write(pBuffer,ret);
        }
        else if(0==ret){//数据已经读到了末尾了
            break;
        }
        else {
            QMessageBox::warning(this, "上传文件", "上传文件失败，读文件失败");
            break;
        }
    }
    file.close();
    delete [] (pBuffer);
    pBuffer=NULL;
}

void Book::delRegeFile()
{
    //获得当前所在的目录
    QString strCurPath = TcpClient::getinstance().curPath();
    //获得点击删除的文件
    QListWidgetItem *pItem =  m_pBookListW->currentItem();
    //判断
    if(NULL==pItem)
    {
        QMessageBox::warning(this,"删除文件","请选择要删除的文件");
    }
    else
    {
        //列表上面的文件名称
        QString strDelName = pItem->text();
        //路径太长了，放在caMsg里面，名字就放在caData里面
        PDU *pdu =mkPDU(strCurPath.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_DELETE_FILE_REQUEST;
        strncpy((char*)(pdu->caData),strDelName.toStdString().c_str(),strDelName.size());
        memcpy(pdu->caMsg,strCurPath.toStdString().c_str(),strCurPath.size());
        //发送给服务器
        TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
}

void Book::downloadFile()
{
    //获得下载的文件名字
    //获得当前所在的目录
    QString strCurPath = TcpClient::getinstance().curPath();
    //获得点击删除的文件
    QListWidgetItem *pItem =  m_pBookListW->currentItem();
    //判断
    if(NULL==pItem)
    {
        QMessageBox::warning(this,"下载文件","请选择要下载的文件");
    }
    else
    {
        //可能还没有输入路径的时候就已经回复了，所以放在前面
        //定义存放位置
        QString strSaveFilePath = QFileDialog::getSaveFileName();
        if(strSaveFilePath.isEmpty())
        {
            QMessageBox::warning(this, "下载文件","请指定要保存的位置");
            strSaveFilePath.clear();
        }
        else {
            m_strSaveFilePath = strSaveFilePath;
        }
        //当前网盘所在的路径
        QString strCurPath = TcpClient::getinstance().curPath();
        PDU *pdu =mkPDU(strCurPath.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST;
        //文件名字
        QString strFileName = pItem->text();
        strncpy((char*)(pdu->caData),strFileName.toStdString().c_str(),strFileName.size());
        memcpy(pdu->caMsg,strCurPath.toStdString().c_str(),strCurPath.size());

        //发送给服务器
        TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        //可能还没有输入路径的时候就已经回复了
    }
}

void Book::shareFile()
{
    //获得点击删除的文件
    QListWidgetItem *pItem =  m_pBookListW->currentItem();
    //判断
    if(NULL==pItem)
    {
        QMessageBox::warning(this,"分享文件","请选择分享的文件");
        return;
    }
    else
    {//获得分享的文件名
        //文件名字
        m_strShareFileName = pItem->text();
    }
    //获得好友列表
    Friend *pFriend = OpeWidget::getInstance().getFriend();
    QListWidget *pFriendList = pFriend->getFriendlist();
    ShareFile::getinstance().updateFriend(pFriendList);
    if(ShareFile::getinstance().isHidden())
    {
        ShareFile::getinstance().show();
    }
}

void Book::moveFile()
{
    //选择要移动的文件
    QListWidgetItem *pCurItem = m_pBookListW->currentItem();
    if(NULL != pCurItem)
    {//表示选择了一个文件
        //获得文件名字
        m_strMoveFileName = pCurItem->text();
        //当前所在的路径
        QString strCurPath =  TcpClient::getinstance().curPath();
        //将路径和文件名拼接成一个访问的路径
        m_strMoveFilePath = strCurPath +'/'+ m_strMoveFileName;
        //选择移动到那个文件夹里面去
        m_pSelectDirPB->setEnabled(true); //可以进行点击了
    }
    else {
        QMessageBox::warning(this, "移动文件", "请选择要移动的文件");
    }
}

void Book::selectDestDir()
{
    //选择要移动的文件
    QListWidgetItem *pCurItem = m_pBookListW->currentItem();
    if(NULL != pCurItem)
    {//表示选择了一个文件
        //获得目的地路径
        QString strDestDir = pCurItem->text();
        //当前所在的路径
        QString strCurPath =  TcpClient::getinstance().curPath();
        //将路径和文件名拼接成一个访问的路径
        m_strDestDir = strCurPath+'/'+strDestDir;
        //选择移动到那个文件夹里面去
        //产生PDU，发送移动文件的请求
        int srclen = m_strMoveFilePath.size();
        int destlen = m_strDestDir.size();
        PDU *pdu = mkPDU(srclen+destlen+2);
        pdu->uiMsgType = ENUM_MSG_TYPE_MOVE_FILE_REQUEST;
        sprintf(pdu->caData,"%d %d %s", srclen, destlen, m_strMoveFileName.toStdString().c_str());
        memcpy(pdu->caMsg,m_strMoveFilePath.toStdString().c_str(),srclen);
        memcpy((char*)(pdu->caMsg)+(srclen+1), m_strDestDir.toStdString().c_str(),destlen);
        TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        free(pdu);
        pdu = NULL;
    }
    else {
        QMessageBox::warning(this, "移动文件", "请选择要移动的文件");
    }
    m_pSelectDirPB->setEnabled(false);
}




bool Book::getDownloadStatus()
{
    return m_bDownload;
}

QString Book::getShowFileName()
{
    return m_strShareFileName;
}

QString Book::getSaveFilePath()
{
    return m_strSaveFilePath;
}











