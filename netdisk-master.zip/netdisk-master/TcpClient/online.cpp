#include "online.h"
#include "ui_online.h"
#include <QDebug>
#include "tcpclient.h"
Online::Online(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Online)
{
    ui->setupUi(this);
}

Online::~Online()
{
    delete ui;
}

void Online::showUsr(PDU *pdu)
{
    if(NULL==pdu){
        return;
    }
    //每32个给他拷贝出来
    uint uiSize = pdu->uiMsgLen/32;
    char caTmp[32];
    for(uint i=0; i<uiSize; i++){
        memcpy(caTmp, (char*)(pdu->caMsg)+i*32,32);
        ui->online_lw->addItem(caTmp);
    }
}

void Online::on_addFriendpb_clicked()
{
    //发送当前点击的行,通过currentItem获得当前的文字信息
    QListWidgetItem *pItem = ui->online_lw->currentItem();
    //要加的好友的用户名
    QString strPerUsrName = pItem->text();
    //获得自己的名字
    QString strLoginName = TcpClient::getinstance().loginName();

    PDU *pdu = mkPDU(0);
    pdu->uiMsgType = ENUM_MSG_TYPE_ADD_FRIEND_REQUEST;
    //你要添加谁？你是谁
    //获得数据的地址-要加的好友的用户名
    memcpy(pdu->caData, strPerUsrName.toStdString().c_str(), strPerUsrName.size());
    //登录的名字，往后放32个字节——自己的用户名
    memcpy(pdu->caData+32, strLoginName.toStdString().c_str(),strLoginName.size());
    //将信息发送出去
    TcpClient::getinstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
    free(pdu);
    pdu=NULL;
}























