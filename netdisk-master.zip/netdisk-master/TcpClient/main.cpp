#include "tcpclient.h"

#include <QApplication>
//#include "opewidget.h"
//#include "online.h"
//#include "friend.h"
#include "sharefile.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //    TcpClient w;
    //    w.show();
    //    OpeWidget w;
    //    w.show();
    //    Online w;
    //    w.show();
    //    Friend w;
    //    w.show();
    //    ShareFile w;
    //    w.test();
    //    w.show();
    //    Book w;
    //    w.show();
    TcpClient::getinstance().show();
    return a.exec();
}
