#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QMainWindow>
//将文件读取出来
#include <QFile>
//包含 通过TCPsocket来连接服务器和收发服务器数据
#include <QTcpSocket>
//将协议包含进来
#include "protocal.h"
#include "opewidget.h"
QT_BEGIN_NAMESPACE
namespace Ui { class TcpClient; }
QT_END_NAMESPACE

class TcpClient : public QMainWindow
{
    Q_OBJECT

public:
    TcpClient(QWidget *parent = nullptr);
    ~TcpClient();
    void loadConfig();


    static TcpClient &getinstance();

    //封装一个发送函数,获得他的引用
    QTcpSocket &getTcpSocket();

    QString loginName();
    //当前路径函数
    QString curPath();
    //返回上一级定义当前路径
    void setCurPath(QString strCurPath);

public slots:
    //查看是否服务器连接成功
    void showConfig();

private slots:
    //void on_sendBt_clicked();

    void on_login_pb_clicked();

    void on_regist_pb_clicked();

    void on_cancel_pb_clicked();
    void recvMsg();

private:
    Ui::TcpClient *ui;
    QString m_strIP;
    quint16 m_usPort;
    //通过m_tcpSocket连接服务器，与服务器之间进行数据交互
    QTcpSocket m_tcpSocket;
    //添加好友时候，自己的用户名
    QString m_strLoginName;
    //定义路径
    QString m_strCurPath;
    QFile m_file;


};
#endif // TCPCLIENT_H
