#ifndef FRIEND_H
#define FRIEND_H

#include <QWidget>
#include<QTextEdit>//信息显示
#include <QListWidget>//存放已经增加的好友
#include <QLineEdit> //存放信息的输入
#include <QPushButton> //按钮
#include <QVBoxLayout> //垂直布局
#include <QHBoxLayout> //水平布局
#include "online.h"

class Friend : public QWidget
{
    Q_OBJECT
public:
    explicit Friend(QWidget *parent = nullptr);
    void ShowAllOnlineUser(PDU *pdu);
    void updateFriendList(PDU *pdu);
    void updateGroupMsg(PDU *pdu);
    QString m_strSearchName;
    QListWidget *getFriendlist();
signals:
private:
    QTextEdit *m_pShowMsgTE;
    QListWidget *m_pFriendListWidget;
    QLineEdit *m_pInputMsgLE;

    QPushButton *m_pDelFriendPB;//删除好友列表
    QPushButton *m_pFlushFriendPB;//刷新好友列表
    QPushButton *m_pShowOnlineUsrPB;//查看在线用户
    QPushButton *m_pSearchUsrPB;//查看用户
    QPushButton *m_pMsgSendPB;//发送信息按钮
    QPushButton *m_pPrivateChatPB;//私聊按钮

    //产生online的对象
    Online *m_pOnline;


public slots:
    void showOnline();
    //查找用户
    void searchUser();
    //刷新好友列表
    void flushFriend();
    //删除好友
    void deleteFriend();
    //私聊槽函数处理
    void privateChat();
    //群聊槽函数
    void groupChat();


};

#endif // FRIEND_H
