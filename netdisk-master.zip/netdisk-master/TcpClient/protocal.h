#ifndef PROTOCAL_H
#define PROTOCAL_H
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
typedef  unsigned int unit;
#define REGIST_OK "regist ok"
#define REGIST_FAILED "regist failed : name existed"

#define LOGIN_OK "login ok!"
#define LOGIN_FAILED "login failed : name or pwd or relogin!"


#define SEARCH_USER_NO "No such people!"
#define SEARCH_USER_ONLINE "online!"
#define SEARCH_USER_OFFLINE "offline!"

#define UNKNOW_ERROR "unknown error!"
#define EXISTED_FRIEND "friend existed!"
#define ADD_FRIEND_OFFLINE "user offline!"
#define ADD_FRIEND_NO_EXISTED "user not existed!"

#define DELETE_FRIEND_OK "delete friend ok!"


#define DIR_NO_EXISTED "current dir not existed!"
#define FILE_NAME_EXISTED "file name exist!"
#define CREATE_DIR_OK "create dir ok!"

#define DELETE_DIR_OK "delete dir ok!"
#define DELETE_DIR_FAILED "create dir failed:is regular file!"

#define RENAME_FILE_OK "rename file ok!"
#define RENAME_FILE_FAILED "rename file failed:is regular file!"


#define ENTERE_DIR_OK "enter dir ok!"
#define ENTERE_DIR_FAILED "enter dir failed:is regular dir!"

#define UPLOAD_FILE_OK "upload file ok!"
#define UPLOAD_FILE_FAILED "upload file failed!"

#define DELETE_FILE_OK "delete file ok!"
#define DELETE_FILE_FAILED "delete file failed: is Dir!"

#define SHARE_FILE_OK "share file ok!"
#define SHARE_FILE_FAILED "share file failed!"

#define MOVE_FILE_OK "move file ok!"
#define MOVE_FILE_FAILED "move file failed:is regular file!"

#define COMMON_ERROR "operate falied: system is busy!"
//消息类型
enum ENUM_MSG_TYPE
{
    //最小的
    ENUM_MSG_TYPE_MIN = 0,

    //注册
    ENUM_MSG_TYPE_REGIST_REQUEST,      //注册请求
    ENUM_MSG_TYPE_REGIST_RESPOND,      //注册回复
    //登录
    ENUM_MSG_TYPE_LOGIN_REQUEST,        //登录请求
    ENUM_MSG_TYPE_LOGIN_RESPOND,        //登录回复

    ENUM_MSG_TYPE_ALL_ONLINE_REQUEST,  //在线用户请求
    ENUM_MSG_TYPE_ALL_ONLINE_RESPOND,  //在线用户回复

    ENUM_MSG_TYPE_SEARCH_USER_REQUEST,  //搜索用户请求
    ENUM_MSG_TYPE_SEARCH_USER_RESPOND,  //搜索用户回复

    ENUM_MSG_TYPE_ADD_FRIEND_REQUEST,  //添加好友请求
    ENUM_MSG_TYPE_ADD_FRIEND_RESPOND,  //添加好友回复

    ENUM_MSG_TYPE_ADD_FRIEND_AGGREE,  //同意添加好友请求
    ENUM_MSG_TYPE_ADD_FRIEND_REFUSE,  //不同意添加好友回复

    ENUM_MSG_TYPE_FLUSH_FRIEND_REQUEST,  //刷新好友请求
    ENUM_MSG_TYPE_FLUSH_FRIEND_RESPOND,  //刷新好友回复

    ENUM_MSG_TYPE_DELETE_FRIEND_REQUEST,  //刷新好友请求
    ENUM_MSG_TYPE_DELETE_FRIEND_RESPOND,  //刷新好友回复

    ENUM_MSG_TYPE_PRIVATE_CHAT_REQUEST,  //私聊请求
    ENUM_MSG_TYPE_PRIVATE_CHAT_RESPOND,  //私聊回复

    ENUM_MSG_TYPE_GROUP_CHAT_REQUEST,  //群聊请求
    ENUM_MSG_TYPE_GROUP_CHAT_RESPOND,  //群聊回复

    ENUM_MSG_TYPE_CREATE_DIR_REQUEST,  //创建文件夹请求
    ENUM_MSG_TYPE_CREATE_DIR_RESPOND,  //创建文件夹回复

    ENUM_MSG_TYPE_FLUSH_DIR_REQUEST,  //刷新文件夹请求
    ENUM_MSG_TYPE_FLUSH_DIR_RESPOND,  //刷新文件夹回复

    ENUM_MSG_TYPE_DELETE_DIR_REQUEST,  //删除目录请求
    ENUM_MSG_TYPE_DELETE_DIR_RESPOND,  //删除目录回复

    ENUM_MSG_TYPE_RENAME_FILE_REQUEST,  //重命名文件请求
    ENUM_MSG_TYPE_RENAME_FILE_RESPOND,  //重命名文件回复

    ENUM_MSG_TYPE_ENTER_DIR_REQUEST,  //进入文件夹请求
    ENUM_MSG_TYPE_ENTER_DIR_RESPOND,  //进入文件夹回复

    ENUM_MSG_TYPE_UPLOAD_FILE_REQUEST,  //上传文件请求
    ENUM_MSG_TYPE_UPLOAD_FILE_RESPOND,  //上传文件回复

    ENUM_MSG_TYPE_DELETE_FILE_REQUEST,  //删除常规文件请求
    ENUM_MSG_TYPE_DELETE_FILE_RESPOND,  //删除常规文件回复

    ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST,  //下载文件请求
    ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND,  //下载文件回复

    ENUM_MSG_TYPE_SHARE_FILE_REQUEST,  //分享文件请求
    ENUM_MSG_TYPE_SHARE_FILE_RESPOND,  //分享文件回复

    ENUM_MSG_TYPE_SHARE_FILE_NOTE, //共享文件通知
    ENUM_MSG_TYPE_SHARE_FILE_NOTE_RESPOND, //共享文件通知

    ENUM_MSG_TYPE_MOVE_FILE_REQUEST, //移动文件请求
    ENUM_MSG_TYPE_MOVE_FILE_RESPOND, //移动文件回复

    //设置为32位。因为我们是要赋给一个无符号的整型
    ENUM_MSG_TYPE_MAX = 0x00ffffff,
};

struct FileInfo
{
    char caFileName[32];//文件名字
    int  iFileType;//文件类型

};


struct PDU{
    unit uiPDULen; //总的协议数据单元大小
    unit uiMsgType; //消息类型，数据是干嘛的
    char caData[64]; //文件名
    unit uiMsgLen; //实际消息长度
    int caMsg[]; //实际消息
};

//定义一些函数,存储一个实际消息的长度
PDU *mkPDU (unit uiMsgLen);

#endif // PROTOCAL_H
