#ifndef SHAREFILE_H
#define SHAREFILE_H

#include <QWidget>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QButtonGroup>
#include <QScrollArea>
#include <QCheckBox>
#include <QListWidget>
#include "opewidget.h"
class ShareFile : public QWidget
{
    Q_OBJECT
public:
    explicit ShareFile(QWidget *parent = nullptr);
    static ShareFile &getinstance();
    //测试好友
    void test();
    //更新friend
    void updateFriend(QListWidget *pFriendList);
public slots:
    //添加分享文件槽函数
    void cancleSelect();//取消选择
    void allSelect();//全部选择
    void okShare(); //确定分享
    void cancleShare();//取消分享


signals:
private:
    //全选
    QPushButton *m_pSelectAllPB;
    //取消
    QPushButton *m_pCancelSelectPB;
    //确定
    QPushButton *m_pOKPB;
    //取消分享
    QPushButton *m_pCancelPB;
    //中间显示好友的区域
    QScrollArea *m_pSA;
    QWidget *m_pFriendW;
    QVBoxLayout *m_FriendWVBL;
    QButtonGroup *m_pButtonGroup;
};

#endif // SHAREFILE_H
