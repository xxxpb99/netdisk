#include "tcpclient.h"
#include "ui_tcpclient.h"
#include <QByteArray>
#include <QtDebug>
#include <QMessageBox>
#include <QHostAddress>
#include "privatechat.h"

TcpClient::TcpClient(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TcpClient)
{
    ui->setupUi(this);
    resize(300,250);
    //ui->lineEdit->setText("hello");
    loadConfig();
    connect(&m_tcpSocket, SIGNAL(connected()), this, SLOT(showConfig()));
    connect(&m_tcpSocket, SIGNAL(readyRead()), this, SLOT(recvMsg()));
    //连接服务器
    m_tcpSocket.connectToHost(QHostAddress(m_strIP), m_usPort);
}

TcpClient::~TcpClient()
{
    delete ui;
}

void TcpClient::loadConfig()
{
    QFile file(":/client.config");
    if(file.open(QIODevice::ReadOnly)){
        QByteArray baData = file.readAll();
        //将字节转换成字符串
        //c_str()将首地址转换成char*类型的
        QString strData = baData.toStdString().c_str();
        //        qDebug()<<strData;
        file.close();

        //切分字符串
        strData.replace("\r\n", " ");
        //qDebug()<<strData;
        //按照空格进行切分--是一个字符串列表
        QStringList strList =  strData.split(" ");
        //切分完成之后打印一下
        //        for(int i=0; i<strList.size(); i++){
        //            qDebug()<<"------>"<<strList[i];
        //        }

        m_strIP = strList.at(0);
        //端口现在是字符串，现在得转换成无符号的整型
        m_usPort = strList.at(1).toUShort();
        qDebug()<<"ip"<<m_strIP <<"port"<<m_usPort;
    }
    else {
        QMessageBox::critical(this, "open config", "open config failed");
    }
}

TcpClient &TcpClient::getinstance()
{
    static TcpClient instance;
    return  instance;
}

QTcpSocket &TcpClient::getTcpSocket()
{
    return  m_tcpSocket;
}

QString TcpClient::loginName()
{
    return  m_strLoginName;
}

QString TcpClient::curPath()
{
    return  m_strCurPath;
}

void TcpClient::setCurPath(QString strCurPath)
{
    m_strCurPath = strCurPath;
}


void TcpClient::showConfig()
{
    QMessageBox::information(this, "连接服务器", "连接服务器成功");
}


#if 0
void TcpClient::on_sendBt_clicked()
{
    //首先获得输入框的信息
    QString strMsg = ui->lineEdit->text();
    if(!strMsg.isEmpty()){
        //直接发送出去
        //协议
        //strMsg.size()+1加一个\0
        PDU *pdu = mkPDU(strMsg.size()+1);
        //消息类型
        pdu->uiMsgType=8888;
        //拷贝数据 先换成C++的字符串，再获得数据的首地址
        memcpy(pdu->caMsg, strMsg.toStdString().c_str(),strMsg.size());
        m_tcpSocket.write((char*)pdu, pdu->uiPDULen);
        //释放空间
        free (pdu);
        pdu =NULL;
    }
    else {
        QMessageBox::warning(this, "信息发送", "发送的信息不能为空");
    }
}
#endif

void TcpClient::on_login_pb_clicked()
{
    //获得界面数据
    QString strName = ui->name_le->text();
    QString strPwd = ui->pwd_le->text();
    //如果是空的
    if(!strName.isEmpty()&&!strPwd.isEmpty()){
        //发送登录请求
        //将用户名和密码填充到pdu里面去
        //消息部分不用放数据，直接写0
        m_strLoginName = strName;
        PDU *pdu = mkPDU(0);
        //消息类型
        pdu->uiMsgType = ENUM_MSG_TYPE_LOGIN_REQUEST;
        //将数据拷贝进去，也可以用strnpy
        memcpy(pdu->caData, strName.toStdString().c_str(),32);
        //从后面32个字节开始放pdu->caData+32，放我的密码，也都是放32个
        memcpy(pdu->caData+32, strPwd.toStdString().c_str(),32);
        //通过socket将他发送出去
        m_tcpSocket.write((char*)pdu, pdu->uiPDULen);
        //释放空间
        free (pdu);
        pdu =NULL;

    }else {
        QMessageBox::critical(this, "登录", "登录失败，用户名或者密码为空");
    }
}

void TcpClient::on_regist_pb_clicked()
{
    //获得界面数据
    QString strName = ui->name_le->text();
    QString strPwd = ui->pwd_le->text();
    //如果是空的
    if(!strName.isEmpty()&&!strPwd.isEmpty()){
        //发送注册请求
        //将用户名和密码填充到pdu里面去
        //消息部分不用放数据，直接写0
        PDU *pdu = mkPDU(0);
        //消息类型
        pdu->uiMsgType = ENUM_MSG_TYPE_REGIST_REQUEST;
        //将数据拷贝进去，也可以用strnpy
        memcpy(pdu->caData, strName.toStdString().c_str(),32);
        //从后面32个字节开始放pdu->caData+32，放我的密码，也都是放32个
        memcpy(pdu->caData+32, strPwd.toStdString().c_str(),32);
        //通过socket将他发送出去
        m_tcpSocket.write((char*)pdu, pdu->uiPDULen);
        //释放空间
        free (pdu);
        pdu =NULL;

    }else {
        QMessageBox::critical(this, "信息注册", "注册失败，用户名或者密码为空");
    }
}

void TcpClient::on_cancel_pb_clicked()
{

}

void TcpClient::recvMsg()
{
    if(!OpeWidget::getInstance().getBook()->getDownloadStatus())
    {
        //打印当前可读的数据大小
        qDebug()<<m_tcpSocket.bytesAvailable();
        //收数据
        uint uiPDULen =0;
        //先收4个字节大小的数
        m_tcpSocket.read((char*)&uiPDULen, sizeof (uint));
        //根据总的大小，计算实际消息长度
        uint uiMsgLen = uiPDULen-sizeof (PDU);
        //根据实际消息长度，产生一个pdu，接收剩余的数据
        PDU *pdu = mkPDU(uiMsgLen);
        //(char*)pdu +sizeof (uint)从这儿开始放，放uiPDULen-sizeof (uint)些数据
        m_tcpSocket.read((char*)pdu +sizeof (uint),uiPDULen-sizeof (uint));
        //qDebug()<<pdu->uiMsgType<<(char*)pdu->caMsg;
        //判断消息类型
        switch (pdu->uiMsgType) {
        //---------------------------注册---------------------------------
        case ENUM_MSG_TYPE_REGIST_RESPOND:
        {
            if(0== strcmp(pdu->caData, REGIST_OK)){
                QMessageBox::information(this, "注册",REGIST_OK);
            }
            else if(0== strcmp(pdu->caData, REGIST_FAILED)){
                QMessageBox::warning(this, "注册", REGIST_FAILED);
            }
            break;
        }

            //-----------------------------登录------------------------------
        case ENUM_MSG_TYPE_LOGIN_RESPOND:
        {
            if(0== strcmp(pdu->caData, LOGIN_OK)){
                m_strCurPath = QString("./%1").arg(m_strLoginName);
                QMessageBox::information(this, "登录", LOGIN_OK);
                //将好友界面显示出来
                //通过调用它的静态的函数获得对象的引用，通过对象的引用将窗口显示出来
                OpeWidget::getInstance().show();
                //this->hide();
                hide();
            }
            else if(0== strcmp(pdu->caData, LOGIN_FAILED)){
                QMessageBox::warning(this, "登录", LOGIN_FAILED);
            }
            break;
        }
            //------------------------------在线回复----------
        case ENUM_MSG_TYPE_ALL_ONLINE_RESPOND:
        {
            //将在线好友的名字提取出来，显示在还有列表上面
            OpeWidget::getInstance().getFriend()->ShowAllOnlineUser(pdu);
            break;
        }
            //-------------------------------查找回复-----------------------
        case ENUM_MSG_TYPE_SEARCH_USER_RESPOND:
        {
            if(0==strcmp(SEARCH_USER_NO,pdu->caData)){
                QMessageBox::information(this, "搜索", QString("%1: not exist").arg(OpeWidget::getInstance().getFriend()->m_strSearchName));
            }
            else if (0==strcmp(SEARCH_USER_ONLINE,pdu->caData)) {
                QMessageBox::information(this, "搜索", QString("%1: online").arg(OpeWidget::getInstance().getFriend()->m_strSearchName));
            }
            else if (0==strcmp(SEARCH_USER_OFFLINE,pdu->caData)) {
                QMessageBox::information(this, "搜索", QString("%1: offline").arg(OpeWidget::getInstance().getFriend()->m_strSearchName));
            }
            break;
        }

            //---------------------------添加好友---------------------
        case ENUM_MSG_TYPE_ADD_FRIEND_REQUEST:
        {
            //同意添加好友还是不同意添加好友
            char caName[32]={'\0'};
            strncpy(caName,pdu->caData+32,32);
            int ret = QMessageBox::information(this,"添加好友",QString("%1 what to add you as friend?").arg(caName),
                                               QMessageBox::Yes,QMessageBox::No);

            PDU *respdu =mkPDU(0);
            //将对方的名字添加进来,要不然不知道是谁添加你就尴尬了
            memcpy(respdu->caData,pdu->caData,64);

            if(QMessageBox::Yes==ret){
                //同意添加这个好友
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_AGGREE;
            }
            else{
                //不同意添加这个好友
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_REFUSE;
            }
            m_tcpSocket.write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_ADD_FRIEND_RESPOND:
        {
            QMessageBox::information(this,"添加好友",pdu->caData);
            break;
        }
        case  ENUM_MSG_TYPE_ADD_FRIEND_AGGREE:
        {
            char caPerName[32] = {'\0'};
            strncpy(caPerName, pdu->caData, 32);
            QMessageBox::information(this,"添加好友",QString("添加%1好友成功").arg(caPerName));
            break;
        }

        case  ENUM_MSG_TYPE_ADD_FRIEND_REFUSE:
        {
            char caPerName[32] = {'\0'};
            strncpy(caPerName, pdu->caData, 32);
            QMessageBox::information(this,"添加好友",QString("添加%1好友失败").arg(caPerName));
            break;
        }

            //-----------------------刷新好友-------------------
        case ENUM_MSG_TYPE_FLUSH_FRIEND_RESPOND:
        {
            OpeWidget::getInstance().getFriend()->updateFriendList(pdu);
            break;
        }


            //-------------------删除好友-------------
        case ENUM_MSG_TYPE_DELETE_FRIEND_REQUEST:
        {
            //谁删除了我
            char caName[32]={'\0'};
            memcpy(caName,pdu->caData,32);
            QMessageBox::information(this,"删除好友",QString ("%1删除了你作为他的好友").arg(caName));
            break;
        }
        case ENUM_MSG_TYPE_DELETE_FRIEND_RESPOND:
        {
            QMessageBox::information(this,"删除好友","删除好友成功");
            break;
        }
            //-----------------------私聊好友----------------------
        case ENUM_MSG_TYPE_PRIVATE_CHAT_REQUEST:
        {
            if(PrivateChat::getInstance().isHidden())
            {
                PrivateChat::getInstance().show();
            }
            char caSendName[32]={'\0'};
            memcpy(caSendName,pdu->caData,32);
            QString strSendName = caSendName;
            PrivateChat::getInstance().setChatName(strSendName);
            PrivateChat::getInstance().updateMsg(pdu);
            break;
        }

            //-------------------------群聊好友--------------------------
        case ENUM_MSG_TYPE_GROUP_CHAT_REQUEST:
        {
            OpeWidget::getInstance().getFriend()->updateGroupMsg(pdu);
            break;
        }

            //----------------------创建文件夹----------------------------
        case ENUM_MSG_TYPE_CREATE_DIR_RESPOND:
        {
            QMessageBox::information(this,"创建文件",pdu->caData);
            break;
        }

            //---------------------刷新文件夹------------------------
        case ENUM_MSG_TYPE_FLUSH_DIR_RESPOND:
        {
            OpeWidget::getInstance().getBook()->updateFileList(pdu);
            QString strEnterDir = OpeWidget::getInstance().getBook()->enterDir();
            if(!strEnterDir.isEmpty()){
                m_strCurPath=m_strCurPath+"/"+strEnterDir;
                qDebug()<<"enter dir:"<<m_strCurPath;
            }
            break;
        }

            //---------------------删除目录------------------------
        case ENUM_MSG_TYPE_DELETE_DIR_RESPOND:
        {
            QMessageBox::information(this,"删除文件夹",pdu->caData);
            break;
        }
            //---------------------重命名文件------------------------
        case ENUM_MSG_TYPE_RENAME_FILE_RESPOND:
        {
            QMessageBox::information(this,"重命名文件",pdu->caData);
            break;
        }
            //---------------------进入文件夹------------------------
        case ENUM_MSG_TYPE_ENTER_DIR_RESPOND:
        {
            OpeWidget::getInstance().getBook()->clearEnterDir();
            QMessageBox::information(this,"进入文件夹",pdu->caData);
            break;
        }
            //---------------------上传文件------------------------
        case ENUM_MSG_TYPE_UPLOAD_FILE_RESPOND:
        {
            QMessageBox::information(this,"进入文件夹",pdu->caData);
            break;
        }
            //---------------------删除常规文件------------------------
        case ENUM_MSG_TYPE_DELETE_FILE_RESPOND:
        {
            QMessageBox::information(this,"删除常规文件",pdu->caData);
            break;
        }

            //---------------------下载文件文件------------------------
        case ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND:
        {
            qDebug()<<pdu->caData;
            //QMessageBox::information(this,"下载文件",pdu->caData);
            //定义文件的名字
            char caFileName[32] ={'\0'};
            sscanf(pdu->caData, "%s %lld", caFileName, &(OpeWidget::getInstance().getBook()->m_iTotal));
            if(strlen(caFileName)>0 &&OpeWidget::getInstance().getBook()->m_iTotal >0)
            {
                OpeWidget::getInstance().getBook()->setDownloadStatus(true);//现在处于下载状态
                //打开文件
                m_file.setFileName(OpeWidget::getInstance().getBook()->getSaveFilePath());
                if(!m_file.open(QIODevice::WriteOnly))
                {
                    QMessageBox::warning(this, "下载文件","获得保存文件的路径失败");
                }
            }
            break;
        }

            //---------------------分享文件------------------------
        case ENUM_MSG_TYPE_SHARE_FILE_RESPOND:
        {
            QMessageBox::information(this,"共享文件",pdu->caData);
            break;
        }
        case ENUM_MSG_TYPE_SHARE_FILE_NOTE:
        {
            //是否接收对方共享的文件
            char *pPath = new char[pdu->uiMsgLen];
            memcpy(pPath, pdu->caMsg,pdu->uiMsgLen);
            // //aa//bb/cc
            char *pos =  strrchr(pPath, '/');
            qDebug()<<pos;
            if(NULL != pos)
            {//表示找到了
                pos++;
                QString strNote = QString("%1 share file->%2 \n Do you accept?").arg(pdu->caData).arg(pos);
                int ret = QMessageBox::question(this,"共享文件",strNote);
                if(QMessageBox::Yes==ret)
                {
                    PDU *respdu = mkPDU(pdu->uiMsgLen);
                    respdu->uiMsgType =ENUM_MSG_TYPE_SHARE_FILE_NOTE_RESPOND;
                    memcpy(respdu->caMsg, pdu->caMsg,pdu->uiMsgLen);
                    //接收者名字
                    QString strName = TcpClient::getinstance().loginName();
                    strcpy(respdu->caData,strName.toStdString().c_str());
                    m_tcpSocket.write((char*)respdu, respdu->uiPDULen);
                }
            }
            break;
        }
            //---------------------移动文件------------------------
        case ENUM_MSG_TYPE_MOVE_FILE_RESPOND:
        {
            QMessageBox::information(this,"移动文件",pdu->caData);
            break;
        }

        default:
            break;
        }
        free (pdu);
        pdu =NULL;
    }
    else {//处于收数据的状态
        QByteArray buffer = m_tcpSocket.readAll();
        m_file.write(buffer);
        Book *pBook = OpeWidget::getInstance().getBook();
        pBook->m_Recived+=buffer.size();
        if(pBook->m_iTotal ==pBook->m_Recived)
        {
            m_file.close();
            pBook->m_iTotal =0;
            pBook->m_Recived =0;
            pBook->setDownloadStatus(false);
            QMessageBox::information(this, "下载文件","下载文件成功");
        }
        else if(pBook->m_iTotal ==pBook->m_Recived) {//收到的数据比原本的数据还要大
            m_file.close();
            pBook->m_iTotal =0;
            pBook->m_Recived =0;
            pBook->setDownloadStatus(false);
            QMessageBox::critical(this, "下载文件","下载文件失败");
        }
    }
}













