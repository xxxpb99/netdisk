#include "protocal.h"


PDU *mkPDU(unit uiMsgLen)
{
    /*
    sizeof(PDU)只会计算 以下的大小
    unit uiPDULen; //总的协议数据单元大小
    unit uiMsgType; //消息类型，数据是干嘛的
    char caData[64]; //文件名
    unit uiMsgLen; //实际消息长度
    */
    //所以总的数据大小就是前面的，加上实际大小
    unit uiPDULen = sizeof(PDU) +uiMsgLen;
    PDU *pdu = (PDU*) malloc(uiPDULen);
    //清空一下
    if(NULL == pdu){
        //结束程序
        exit(EXIT_FAILURE);
    }
    memset(pdu, 0,uiPDULen);
    //重置
    pdu->uiPDULen = uiPDULen;
    pdu->uiMsgLen = uiMsgLen;
    return  pdu;


}
